
-- Coupons: remove broad authenticated read; validate via RPC instead
DROP POLICY IF EXISTS "coupons authenticated read active" ON public.coupons;

CREATE OR REPLACE FUNCTION public.validate_coupon(_code text)
RETURNS TABLE(code text, discount_percent int, expires_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT c.code, c.discount_percent, c.expires_at
  FROM public.coupons c
  WHERE c.code = upper(trim(_code))
    AND c.active = true
    AND (c.expires_at IS NULL OR c.expires_at > now())
    AND (c.max_uses IS NULL OR c.used_count < c.max_uses)
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.validate_coupon(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.validate_coupon(text) TO anon, authenticated;

-- Reviews: stop exposing raw user_id publicly; expose safe view instead
DROP POLICY IF EXISTS "reviews public read" ON public.reviews;

CREATE POLICY "reviews owner read" ON public.reviews
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE OR REPLACE VIEW public.reviews_public
WITH (security_invoker = true) AS
SELECT
  r.id,
  r.product_id,
  r.rating,
  r.comment,
  r.created_at,
  COALESCE(p.full_name, split_part(p.email, '@', 1), 'User') AS display_name
FROM public.reviews r
LEFT JOIN public.profiles p ON p.id = r.user_id;

-- The view uses security_invoker; grant read to everyone and let the underlying
-- table policies decide. Add a permissive SELECT on reviews scoped to the view's
-- safe columns by allowing anon/authenticated to read rows but never user_id
-- directly via PostgREST (achieved by revoking column privilege).
GRANT SELECT ON public.reviews_public TO anon, authenticated;

-- Allow anon/authenticated to read reviews rows but NOT the user_id column,
-- so the view works while direct table reads cannot leak identities.
REVOKE SELECT ON public.reviews FROM anon;
GRANT SELECT (id, product_id, rating, comment, created_at) ON public.reviews TO anon;
GRANT SELECT (id, product_id, rating, comment, created_at) ON public.reviews TO authenticated;

CREATE POLICY "reviews public read safe" ON public.reviews
  FOR SELECT TO anon, authenticated
  USING (true);
