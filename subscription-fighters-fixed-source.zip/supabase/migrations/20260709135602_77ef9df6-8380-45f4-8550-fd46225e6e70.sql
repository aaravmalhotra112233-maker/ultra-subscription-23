CREATE OR REPLACE FUNCTION public.validate_order_before_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  p RECORD;
  c RECORD;
  computed_amount numeric;
  qty int;
BEGIN
  qty := COALESCE(NEW.quantity, 1);
  IF qty < 1 THEN
    RAISE EXCEPTION 'Quantity must be at least 1';
  END IF;

  SELECT id, price, active INTO p FROM public.products WHERE id = NEW.product_id;
  IF NOT FOUND OR NOT p.active THEN
    RAISE EXCEPTION 'Product not available';
  END IF;

  computed_amount := p.price * qty;

  IF NEW.coupon_code IS NOT NULL AND length(NEW.coupon_code) > 0 THEN
    SELECT code, discount_percent, active, expires_at, max_uses, used_count
      INTO c
      FROM public.coupons
      WHERE code = NEW.coupon_code;

    IF NOT FOUND OR NOT c.active THEN
      RAISE EXCEPTION 'Invalid coupon code';
    END IF;
    IF c.expires_at IS NOT NULL AND c.expires_at < now() THEN
      RAISE EXCEPTION 'Coupon expired';
    END IF;
    IF c.max_uses IS NOT NULL AND c.used_count >= c.max_uses THEN
      RAISE EXCEPTION 'Coupon usage limit reached';
    END IF;

    computed_amount := round((computed_amount * (1 - c.discount_percent::numeric / 100))::numeric, 2);
    UPDATE public.coupons SET used_count = used_count + 1 WHERE code = c.code;
  END IF;

  NEW.amount := computed_amount;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS orders_validate_before_insert ON public.orders;
CREATE TRIGGER orders_validate_before_insert
  BEFORE INSERT ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.validate_order_before_insert();