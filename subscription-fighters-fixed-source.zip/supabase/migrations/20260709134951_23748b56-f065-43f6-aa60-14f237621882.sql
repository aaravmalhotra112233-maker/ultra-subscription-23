DROP POLICY IF EXISTS "coupons public read active" ON public.coupons;
CREATE POLICY "coupons authenticated read active"
  ON public.coupons FOR SELECT
  TO authenticated
  USING (active = true);
REVOKE SELECT ON public.coupons FROM anon;