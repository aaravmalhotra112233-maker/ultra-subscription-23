create table public.payment_accounts (
  id uuid primary key default gen_random_uuid(),
  method text not null unique check (method in ('easypaisa','jazzcash')),
  label text not null,
  account_title text not null,
  account_number text not null,
  instructions text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.payment_accounts to anon, authenticated;
grant insert, update, delete on public.payment_accounts to authenticated;
grant all on public.payment_accounts to service_role;
alter table public.payment_accounts enable row level security;
create policy "payment accounts public read" on public.payment_accounts for select using (active = true or has_role(auth.uid(),'admin'));
create policy "payment accounts admin write" on public.payment_accounts for all to authenticated using (has_role(auth.uid(),'admin')) with check (has_role(auth.uid(),'admin'));

insert into public.payment_accounts (method, label, account_title, account_number, instructions) values
  ('easypaisa','Easypaisa','Subscription Fighters','03000000000','Send the exact total to this Easypaisa number, then upload the payment screenshot.'),
  ('jazzcash','JazzCash','Subscription Fighters','03000000000','Send the exact total to this JazzCash number, then upload the payment screenshot.');

create table public.payment_proofs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  method text not null check (method in ('easypaisa','jazzcash')),
  sender_name text not null,
  sender_number text not null,
  transaction_id text,
  amount numeric(10,2),
  screenshot_path text not null,
  status text not null default 'submitted' check (status in ('submitted','verified','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index payment_proofs_order_idx on public.payment_proofs(order_id);
grant select, insert, update, delete on public.payment_proofs to authenticated;
grant all on public.payment_proofs to service_role;
alter table public.payment_proofs enable row level security;
create policy "payment proofs own insert" on public.payment_proofs for insert to authenticated with check (auth.uid() = user_id and exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
create policy "payment proofs own read" on public.payment_proofs for select to authenticated using (auth.uid() = user_id or has_role(auth.uid(),'admin'));
create policy "payment proofs admin update" on public.payment_proofs for update to authenticated using (has_role(auth.uid(),'admin')) with check (has_role(auth.uid(),'admin'));
create policy "payment proofs admin delete" on public.payment_proofs for delete to authenticated using (has_role(auth.uid(),'admin'));

create trigger payment_accounts_updated_at before update on public.payment_accounts for each row execute function public.touch_updated_at();
create trigger payment_proofs_updated_at before update on public.payment_proofs for each row execute function public.touch_updated_at();

create policy "payment proof upload own" on storage.objects for insert to authenticated with check (bucket_id = 'payment-proofs' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "payment proof read own or admin" on storage.objects for select to authenticated using (bucket_id = 'payment-proofs' and ((storage.foldername(name))[1] = auth.uid()::text or has_role(auth.uid(),'admin')));