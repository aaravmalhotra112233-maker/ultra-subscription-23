import { Link } from "@tanstack/react-router";
import { Instagram, Send, MessageCircle } from "lucide-react";
import { contactLinks, CONTACT } from "@/lib/contact";
import logo from "@/assets/logo.png.asset.json";

export function Footer() {
  const c = contactLinks();
  return (
    <footer className="mt-24 border-t border-border/60 bg-[image:var(--gradient-soft)]">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <img src={logo.url} alt="Subscription Fighters logo" className="h-9 w-9 object-contain" />
            <span className="text-lg font-bold tracking-tight">Subscription<span className="gradient-text">Fighters</span></span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Premium digital services, AI tools & memberships for creators, students, freelancers and small teams.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Explore</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/services" className="hover:text-foreground">All services</Link></li>
            <li><Link to="/" className="hover:text-foreground">Home</Link></li>
            <li><Link to="/auth" className="hover:text-foreground">Sign in</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Contact</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><a href={c.whatsapp} target="_blank" rel="noreferrer" className="hover:text-foreground inline-flex items-center gap-2"><MessageCircle className="h-4 w-4" /> WhatsApp</a></li>
            <li><a href={c.instagram} target="_blank" rel="noreferrer" className="hover:text-foreground inline-flex items-center gap-2"><Instagram className="h-4 w-4" /> Instagram</a></li>
            <li><a href={c.telegram} target="_blank" rel="noreferrer" className="hover:text-foreground inline-flex items-center gap-2"><Send className="h-4 w-4" /> Telegram</a></li>
            <li><a href={`mailto:${CONTACT.email}`} className="hover:text-foreground">{CONTACT.email}</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold">Trust</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li>Secure transactions</li>
            <li>Instant delivery</li>
            <li>24/7 chat support</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60 py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Subscription Fighters. All rights reserved.
      </div>
    </footer>
  );
}
