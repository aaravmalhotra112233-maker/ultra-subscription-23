import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Star, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";

export function Reviews({ productId }: { productId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);

  const { data: reviews, isLoading } = useQuery({
    queryKey: ["reviews", productId],
    queryFn: async () => {
      const { data } = await supabase
        .from("reviews_public")
        .select("id,rating,comment,created_at,display_name")
        .eq("product_id", productId)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const avg = reviews?.length
    ? reviews.reduce((s: number, r: any) => s + r.rating, 0) / reviews.length
    : 0;

  const submit = async () => {
    if (!user) return;
    if (comment.trim().length > 1000) return toast.error("Comment too long");
    setSaving(true);
    const { error } = await supabase
      .from("reviews")
      .upsert(
        { product_id: productId, user_id: user.id, rating, comment: comment.trim() || null },
        { onConflict: "product_id,user_id" },
      );
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Thanks for your review!");
    setComment("");
    qc.invalidateQueries({ queryKey: ["reviews", productId] });
  };

  return (
    <section className="mt-14">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Reviews</h2>
        {reviews && reviews.length > 0 && (
          <div className="flex items-center gap-1 text-sm">
            <Stars value={avg} />
            <span className="font-semibold">{avg.toFixed(1)}</span>
            <span className="text-muted-foreground">({reviews.length})</span>
          </div>
        )}
      </div>

      {user ? (
        <div className="glass mt-4 rounded-2xl p-4">
          <div className="text-sm font-medium">Leave a review</div>
          <div className="mt-2 flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} type="button" onClick={() => setRating(n)} aria-label={`${n} stars`}>
                <Star className={`h-6 w-6 ${n <= rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`} />
              </button>
            ))}
          </div>
          <Textarea
            className="mt-3"
            rows={3}
            maxLength={1000}
            placeholder="Share your experience..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <div className="mt-3 flex justify-end">
            <Button onClick={submit} disabled={saving} className="rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Post review"}
            </Button>
          </div>
        </div>
      ) : (
        <div className="glass mt-4 flex items-center justify-between rounded-2xl p-4">
          <span className="text-sm text-muted-foreground">Sign in to leave a review.</span>
          <Button asChild size="sm" variant="outline" className="rounded-full"><Link to="/auth">Sign in</Link></Button>
        </div>
      )}

      <div className="mt-6 space-y-4">
        {isLoading && <div className="h-24 animate-pulse rounded-2xl bg-muted" />}
        {reviews && reviews.length === 0 && (
          <p className="text-sm text-muted-foreground">No reviews yet — be the first!</p>
        )}
        {(reviews ?? []).map((r: any) => (
          <div key={r.id} className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold">{r.display_name || "User"}</div>
              <Stars value={r.rating} />
            </div>
            {r.comment && <p className="mt-2 text-sm text-foreground/80 whitespace-pre-wrap">{r.comment}</p>}
            <div className="mt-1 text-xs text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Stars({ value }: { value: number }) {
  return (
    <div className="flex items-center">
      {[1, 2, 3, 4, 5].map((n) => (
        <Star key={n} className={`h-4 w-4 ${n <= Math.round(value) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`} />
      ))}
    </div>
  );
}
