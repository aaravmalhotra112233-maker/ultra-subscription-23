import { Link } from "@tanstack/react-router";
import { ArrowRight, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { WishlistButton } from "@/components/WishlistButton";
import { Price } from "@/lib/currency";


export type ProductCardData = {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  price: number;
  image_url: string | null;
  featured?: boolean | null;
};

export function ProductCard({ p }: { p: ProductCardData }) {
  return (
    <Link
      to="/product/$slug"
      params={{ slug: p.slug }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card shadow-soft transition hover:-translate-y-1 hover:shadow-glow"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-[image:var(--gradient-soft)]">
        {p.image_url ? (
          <img
            src={p.image_url}
            alt={p.name}
            loading="lazy"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-primary/40">No image</div>
        )}
        {p.featured && (
          <Badge className="absolute left-3 top-3 gap-1 bg-[image:var(--gradient-hero)] text-white shadow-glow">
            <Star className="h-3 w-3" /> Featured
          </Badge>
        )}
        <div className="absolute right-3 top-3"><WishlistButton productId={p.id} /></div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-lg font-semibold tracking-tight">{p.name}</h3>
        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{p.short_description}</p>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xl font-bold gradient-text"><Price usd={Number(p.price)} /></span>
          <span className="inline-flex items-center gap-1 text-sm font-medium text-primary">
            View <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </span>
        </div>
      </div>
    </Link>
  );
}
