import { Globe } from "lucide-react";
import { CURRENCIES, useCurrency, type CurrencyCode } from "@/lib/currency";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export function CurrencySelect({ className }: { className?: string }) {
  const { currency, setCurrency } = useCurrency();

  return (
    <Select value={currency.code} onValueChange={(v) => setCurrency(v as CurrencyCode)}>
      <SelectTrigger
        aria-label="Select currency"
        className={`h-9 w-[112px] rounded-full text-sm ${className ?? ""}`}
      >
        <Globe className="h-4 w-4 text-primary" />
        <SelectValue />
      </SelectTrigger>
      <SelectContent className="max-h-72">
        {Object.values(CURRENCIES).map((c) => (
          <SelectItem key={c.code} value={c.code}>
            {c.code} — {c.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
