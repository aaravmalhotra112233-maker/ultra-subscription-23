import { useState } from "react";
import { ZoomIn, X } from "lucide-react";

export function ImageZoom({
  src,
  alt,
  className,
  imgClassName,
}: {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={`Enlarge image of ${alt}`}
        className={`group relative block h-full w-full cursor-zoom-in overflow-hidden ${className ?? ""}`}
      >
        <img src={src} alt={alt} className={imgClassName ?? "h-full w-full object-cover"} />
        <span className="pointer-events-none absolute bottom-2 right-2 grid h-9 w-9 place-items-center rounded-full bg-background/80 text-foreground opacity-0 shadow-soft backdrop-blur transition group-hover:opacity-100">
          <ZoomIn className="h-4 w-4" />
        </span>
      </button>

      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={alt}
          onClick={() => setOpen(false)}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-background/90 p-4 backdrop-blur-sm animate-in fade-in"
        >
          <button
            type="button"
            aria-label="Close"
            onClick={() => setOpen(false)}
            className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full border border-border/60 bg-card text-foreground shadow-soft"
          >
            <X className="h-5 w-5" />
          </button>
          <img
            src={src}
            alt={alt}
            onClick={(e) => e.stopPropagation()}
            className="max-h-[88vh] max-w-[92vw] cursor-zoom-out rounded-2xl object-contain shadow-glow"
          />
        </div>
      )}
    </>
  );
}
