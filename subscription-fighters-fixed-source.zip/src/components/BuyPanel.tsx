import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Loader2, ShoppingBag, TicketPercent, Check, Minus, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCurrency } from "@/lib/currency";
import { useBuyIntent } from "@/lib/buyIntent";


export function BuyPanel({ productId, productName, price }: { productId: string; productName: string; price: number }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const buyIntent = useBuyIntent();
  const { format, currency } = useCurrency();

  const [code, setCode] = useState("");
  const [applied, setApplied] = useState<{ code: string; percent: number; expiresAt: string | null } | null>(null);
  const [checking, setChecking] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [qty, setQty] = useState(1);

  const unit = applied ? Number((price * (1 - applied.percent / 100)).toFixed(2)) : price;
  const total = Number((unit * qty).toFixed(2));

  useEffect(() => {
    buyIntent?.setIntent({
      productName,
      quantity: qty,
      unitPrice: unit,
      total,
      couponCode: applied?.code ?? null,
      couponPercent: applied?.percent ?? null,
      couponExpiresAt: applied?.expiresAt ?? null,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qty, unit, total, applied?.code, applied?.percent, applied?.expiresAt, productName]);

  const apply = async () => {
    const c = code.trim().toUpperCase();
    if (!c) return;
    setChecking(true);
    const { data, error } = await supabase
      .rpc("validate_coupon", { _code: c })
      .maybeSingle();
    setChecking(false);
    if (error || !data) return toast.error("Invalid or expired coupon");
    setApplied({ code: data.code, percent: data.discount_percent, expiresAt: data.expires_at ?? null });
    toast.success(`Applied ${data.discount_percent}% off`);
  };

  const placeOrder = async () => {
    if (!user) { nav({ to: "/auth" }); return; }
    setPlacing(true);
    const { data, error } = await supabase.from("orders").insert({
      user_id: user.id,
      product_id: productId,
      coupon_code: applied?.code ?? null,
      amount: total,
      quantity: qty,
      status: "pending",
      notes: `Order for ${productName} × ${qty}`,
    }).select("id").single();
    setPlacing(false);
    if (error || !data) return toast.error(error?.message ?? "Could not place order");
    toast.success("Order placed! Continue on chat to complete.");
    nav({ to: "/orders/$id", params: { id: data.id } });
  };


  return (
    <div className="glass mt-6 rounded-2xl p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold">Quantity</div>
        <div className="flex items-center gap-2">
          <Button type="button" size="icon" variant="outline" className="h-9 w-9 rounded-full" onClick={() => setQty(q => Math.max(1, q - 1))} disabled={qty <= 1}>
            <Minus className="h-4 w-4" />
          </Button>
          <Input
            type="number"
            min={1}
            max={999}
            value={qty}
            onChange={(e) => {
              const n = parseInt(e.target.value, 10);
              setQty(Number.isFinite(n) && n > 0 ? Math.min(999, n) : 1);
            }}
            className="h-9 w-16 text-center"
          />
          <Button type="button" size="icon" variant="outline" className="h-9 w-9 rounded-full" onClick={() => setQty(q => Math.min(999, q + 1))}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="mt-4 flex items-center gap-2 text-sm font-semibold">
        <TicketPercent className="h-4 w-4 text-primary" /> Have a coupon?
      </div>
      <div className="mt-2 flex gap-2">
        <Input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="ENTER CODE"
          className="uppercase"
          disabled={!!applied}
        />
        {applied ? (
          <Button variant="outline" onClick={() => { setApplied(null); setCode(""); }}>Remove</Button>
        ) : (
          <Button onClick={apply} disabled={checking || !code.trim()}>
            {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : "Apply"}
          </Button>
        )}
      </div>
      {applied && (
        <div className="mt-2 flex items-center gap-1 text-xs text-emerald-600">
          <Check className="h-3.5 w-3.5" /> {applied.percent}% off with {applied.code}
        </div>
      )}

      <div className="mt-4 flex items-baseline justify-between border-t border-border/60 pt-3">
        <span className="text-sm text-muted-foreground">Total ({qty} × {format(unit)})</span>
        <div className="text-right">
          {applied && <div className="text-xs text-muted-foreground line-through">{format(price * qty)}</div>}
          <div className="text-2xl font-bold gradient-text">{format(total)}</div>
          {currency.code !== "USD" && (
            <div className="text-[11px] text-muted-foreground">≈ ${total.toFixed(2)} USD</div>
          )}
        </div>
      </div>


      {user ? (
        <Button onClick={placeOrder} disabled={placing} size="lg" className="mt-3 w-full rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
          {placing ? <Loader2 className="h-4 w-4 animate-spin" /> : <><ShoppingBag className="mr-1 h-4 w-4" /> Place order</>}
        </Button>
      ) : (
        <Button asChild size="lg" className="mt-3 w-full rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
          <Link to="/auth">Sign in to order</Link>
        </Button>
      )}
      <p className="mt-2 text-xs text-muted-foreground">
        After ordering we contact you on WhatsApp / Telegram to finalize payment and deliver instantly.
      </p>
    </div>
  );
}
