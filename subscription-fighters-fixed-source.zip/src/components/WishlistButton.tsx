import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Heart } from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

export function WishlistButton({ productId, className }: { productId: string; className?: string }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const qc = useQueryClient();

  const { data: item } = useQuery({
    queryKey: ["wishlist", user?.id, productId],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("wishlist")
        .select("id")
        .eq("user_id", user!.id)
        .eq("product_id", productId)
        .maybeSingle();
      return data;
    },
  });

  const saved = !!item;

  const toggle = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) { nav({ to: "/auth" }); return; }
    if (saved) {
      const { error } = await supabase.from("wishlist").delete().eq("id", item!.id);
      if (error) return toast.error(error.message);
      toast.success("Removed from wishlist");
    } else {
      const { error } = await supabase.from("wishlist").insert({ user_id: user.id, product_id: productId });
      if (error) return toast.error(error.message);
      toast.success("Saved to wishlist");
    }
    qc.invalidateQueries({ queryKey: ["wishlist"] });
  };

  return (
    <button
      onClick={toggle}
      aria-label={saved ? "Remove from wishlist" : "Add to wishlist"}
      aria-pressed={saved}
      className={cn(
        "grid h-9 w-9 place-items-center rounded-full bg-background/80 backdrop-blur transition hover:scale-110 hover:bg-background shadow-soft",
        className,
      )}
    >
      <Heart className={cn("h-4 w-4 transition", saved ? "fill-rose-500 text-rose-500" : "text-foreground/70")} />
    </button>
  );
}
