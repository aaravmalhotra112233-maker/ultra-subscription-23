import { Link, useRouter } from "@tanstack/react-router";
import { Menu, X, LogOut, LayoutDashboard, User as UserIcon, Package2, Heart } from "lucide-react";
import { useState } from "react";
import logo from "@/assets/logo.png.asset.json";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { ThemeToggle } from "@/components/ThemeToggle";
import { CurrencySelect } from "@/components/CurrencySelect";

import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const [open, setOpen] = useState(false);
  const { user, isAdmin } = useAuth();
  const router = useRouter();

  const links = [
    { to: "/", label: "Home" },
    { to: "/services", label: "Services" },
    { to: "/about", label: "About" },
    { to: "/contact", label: "Contact" },
  ] as const;

  const signOut = async () => {
    await supabase.auth.signOut();
    router.navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-40 w-full">
      <div className="mx-auto max-w-7xl px-4 pt-4">
        <nav className="glass flex items-center justify-between rounded-2xl px-4 py-3 shadow-soft">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo.url} alt="Subscription Fighters logo" className="h-9 w-9 object-contain" />
            <span className="text-lg font-bold tracking-tight">Subscription<span className="gradient-text">Fighters</span></span>
          </Link>

          <div className="hidden items-center gap-1 md:flex">
            {links.map(l => (
              <Link key={l.to} to={l.to} className="rounded-lg px-3 py-2 text-sm font-medium text-foreground/70 transition hover:bg-accent/60 hover:text-foreground">
                {l.label}
              </Link>
            ))}
          </div>

          <div className="hidden items-center gap-2 md:flex">
            <CurrencySelect />
            <ThemeToggle />
            {user ? (

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="rounded-full">
                    <UserIcon className="h-4 w-4" />
                    <span className="ml-1 max-w-[140px] truncate">{user.email}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => router.navigate({ to: "/orders" })}>
                    <Package2 className="mr-2 h-4 w-4" /> My orders
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => router.navigate({ to: "/wishlist" })}>
                    <Heart className="mr-2 h-4 w-4" /> Wishlist
                  </DropdownMenuItem>
                  {isAdmin && (
                    <DropdownMenuItem onClick={() => router.navigate({ to: "/admin" })}>
                      <LayoutDashboard className="mr-2 h-4 w-4" /> Admin
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut}>
                    <LogOut className="mr-2 h-4 w-4" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button asChild variant="ghost" size="sm"><Link to="/auth">Sign in</Link></Button>
                <Button asChild size="sm" className="rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
                  <Link to="/services">Explore</Link>
                </Button>
              </>
            )}
          </div>

          <div className="flex items-center gap-1 md:hidden">
            <ThemeToggle />
            <button onClick={() => setOpen(v => !v)} aria-label="Menu" className="grid h-9 w-9 place-items-center rounded-lg hover:bg-accent/60">
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </nav>

        {open && (
          <div className="glass mt-2 flex flex-col gap-1 rounded-2xl p-3 md:hidden">
            <div className="px-1 pb-2"><CurrencySelect className="w-full" /></div>

            {links.map(l => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent/60">
                {l.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link to="/orders" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent/60">My orders</Link>
                <Link to="/wishlist" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent/60">Wishlist</Link>
                {isAdmin && <Link to="/admin" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent/60">Admin</Link>}
                <button onClick={() => { setOpen(false); signOut(); }} className="rounded-lg px-3 py-2 text-left text-sm font-medium hover:bg-accent/60">Sign out</button>
              </>
            ) : (
              <Link to="/auth" onClick={() => setOpen(false)} className="rounded-lg bg-[image:var(--gradient-hero)] px-3 py-2 text-center text-sm font-semibold text-white">Sign in</Link>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
