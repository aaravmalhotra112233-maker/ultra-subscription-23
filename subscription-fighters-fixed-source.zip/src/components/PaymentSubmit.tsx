import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Copy, Loader2, ShieldCheck, Upload, Clock, XCircle, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

type Account = {
  id: string;
  method: string;
  label: string;
  account_title: string;
  account_number: string;
  instructions: string | null;
};

const METHOD_STYLE: Record<string, string> = {
  easypaisa: "from-emerald-500 to-emerald-600",
  jazzcash: "from-rose-500 to-rose-600",
};

export function PaymentSubmit({ orderId, userId, amount }: { orderId: string; userId: string; amount: number }) {
  const qc = useQueryClient();
  const [method, setMethod] = useState<string | null>(null);
  const [senderName, setSenderName] = useState("");
  const [senderNumber, setSenderNumber] = useState("");
  const [txnId, setTxnId] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [proofUrl, setProofUrl] = useState<string | null>(null);

  const { data: accounts } = useQuery({
    queryKey: ["payment-accounts"],
    queryFn: async () => {
      const { data } = await supabase
        .from("payment_accounts")
        .select("id,method,label,account_title,account_number,instructions")
        .eq("active", true)
        .order("label");
      return (data ?? []) as Account[];
    },
  });

  const { data: proof } = useQuery({
    queryKey: ["payment-proof", orderId],
    queryFn: async () => {
      const { data } = await supabase
        .from("payment_proofs")
        .select("*")
        .eq("order_id", orderId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
  });

  useEffect(() => {
    let active = true;
    if (!proof?.screenshot_path) { setProofUrl(null); return; }
    supabase.storage.from("payment-proofs").createSignedUrl(proof.screenshot_path, 3600).then(({ data }) => {
      if (active) setProofUrl(data?.signedUrl ?? null);
    });
    return () => { active = false; };
  }, [proof?.screenshot_path]);

  const selected = accounts?.find((a) => a.method === method) ?? null;

  const copy = async (value: string) => {
    try { await navigator.clipboard.writeText(value); toast.success("Number copied"); }
    catch { toast.error("Copy failed"); }
  };

  const submit = async () => {
    if (!selected) return toast.error("Choose a payment method");
    if (!senderName.trim() || !senderNumber.trim()) return toast.error("Enter your name and the number you paid from");
    if (!file) return toast.error("Attach the payment screenshot");
    if (!file.type.startsWith("image/")) return toast.error("Screenshot must be an image");
    if (file.size > 10 * 1024 * 1024) return toast.error("Image must be under 10 MB");

    setSaving(true);
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${userId}/${orderId}-${Date.now()}.${ext}`;
    const up = await supabase.storage.from("payment-proofs").upload(path, file, { upsert: false, contentType: file.type });
    if (up.error) {
      setSaving(false);
      return toast.error(up.error.message);
    }
    const { error } = await supabase.from("payment_proofs").insert({
      order_id: orderId,
      user_id: userId,
      method: selected.method,
      sender_name: senderName.trim(),
      sender_number: senderNumber.trim(),
      transaction_id: txnId.trim() || null,
      amount,
      screenshot_path: path,
    });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Payment details submitted — we'll verify shortly");
    setFile(null);
    qc.invalidateQueries({ queryKey: ["payment-proof", orderId] });
  };

  if (proof) {
    const badge =
      proof.status === "verified"
        ? { Icon: CheckCircle2, cls: "border-emerald-200 bg-emerald-100 text-emerald-800", text: "Payment verified" }
        : proof.status === "rejected"
        ? { Icon: XCircle, cls: "border-rose-200 bg-rose-100 text-rose-800", text: "Payment rejected" }
        : { Icon: Clock, cls: "border-amber-200 bg-amber-100 text-amber-800", text: "Awaiting verification" };
    return (
      <div className="glass mt-6 rounded-2xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-bold">Payment submitted</h2>
          <Badge variant="outline" className={badge.cls}><badge.Icon className="mr-1 h-3.5 w-3.5" /> {badge.text}</Badge>
        </div>
        <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
          <div><dt className="text-xs text-muted-foreground">Method</dt><dd className="font-semibold capitalize">{proof.method}</dd></div>
          <div><dt className="text-xs text-muted-foreground">Paid from</dt><dd className="font-mono">{proof.sender_number}</dd></div>
          <div><dt className="text-xs text-muted-foreground">Sender name</dt><dd>{proof.sender_name}</dd></div>
          {proof.transaction_id && (
            <div><dt className="text-xs text-muted-foreground">Transaction ID</dt><dd className="font-mono">{proof.transaction_id}</dd></div>
          )}
        </dl>
        {proof.admin_note && <p className="mt-3 rounded-xl bg-muted p-3 text-sm">{proof.admin_note}</p>}
        {proofUrl && (
          <a href={proofUrl} target="_blank" rel="noreferrer" className="mt-4 block overflow-hidden rounded-xl border border-border/60">
            <img src={proofUrl} alt="Payment screenshot" className="max-h-72 w-full object-contain bg-muted" />
          </a>
        )}
      </div>
    );
  }

  return (
    <div className="glass mt-6 rounded-2xl p-5">
      <div className="flex items-center gap-2">
        <ShieldCheck className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-bold">Pay for this order</h2>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Choose Easypaisa or JazzCash, send <span className="font-semibold text-foreground">${amount.toFixed(2)}</span> to the number shown, then attach your payment screenshot.
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {(accounts ?? []).map((a) => (
          <button
            key={a.id}
            type="button"
            onClick={() => setMethod(a.method)}
            className={`rounded-2xl border p-4 text-left transition ${
              method === a.method ? "border-primary bg-primary/5 shadow-glow" : "border-border/60 hover:border-primary/50"
            }`}
          >
            <div className={`inline-flex rounded-full bg-gradient-to-r ${METHOD_STYLE[a.method] ?? "from-primary to-primary"} px-3 py-1 text-xs font-semibold text-white`}>
              {a.label}
            </div>
            <div className="mt-2 text-sm text-muted-foreground">{a.account_title}</div>
            <div className="font-mono text-sm font-semibold">{method === a.method ? a.account_number : "Tap to reveal number"}</div>
          </button>
        ))}
      </div>

      {selected && (
        <>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border/60 bg-background/60 p-4">
            <div>
              <div className="text-xs uppercase tracking-wide text-muted-foreground">{selected.label} number</div>
              <div className="font-mono text-lg font-bold">{selected.account_number}</div>
              <div className="text-xs text-muted-foreground">Account title: {selected.account_title}</div>
            </div>
            <Button size="sm" variant="outline" className="rounded-full" onClick={() => copy(selected.account_number)}>
              <Copy className="mr-1 h-3.5 w-3.5" /> Copy
            </Button>
          </div>
          {selected.instructions && <p className="mt-2 text-xs text-muted-foreground">{selected.instructions}</p>}

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div>
              <Label htmlFor="pp-name">Your name</Label>
              <Input id="pp-name" value={senderName} onChange={(e) => setSenderName(e.target.value)} placeholder="Full name on the account" />
            </div>
            <div>
              <Label htmlFor="pp-number">Number you paid from</Label>
              <Input id="pp-number" value={senderNumber} onChange={(e) => setSenderNumber(e.target.value)} placeholder="03XX XXXXXXX" inputMode="tel" />
            </div>
            <div>
              <Label htmlFor="pp-txn">Transaction ID (optional)</Label>
              <Input id="pp-txn" value={txnId} onChange={(e) => setTxnId(e.target.value)} placeholder="TID / reference" />
            </div>
            <div>
              <Label htmlFor="pp-file">Payment screenshot</Label>
              <Input id="pp-file" type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            </div>
          </div>

          <Button onClick={submit} disabled={saving} size="lg" className="mt-4 w-full rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Upload className="mr-1 h-4 w-4" /> Submit payment proof</>}
          </Button>
          <p className="mt-2 text-xs text-muted-foreground">Your screenshot is private — only you and our team can see it.</p>
        </>
      )}
    </div>
  );
}
