"use client";

import { useState, useRef, useEffect, type FormEvent } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { Bot, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
} from "@/components/ai-elements/prompt-input";
import { cn } from "@/lib/utils";

const WELCOME_TEXT =
  "Hi! I'm Subscription Fighters Assistant. Ask me about any service, get recommendations, or check your order status.";

const WELCOME_MESSAGE: UIMessage = {
  id: "welcome",
  role: "assistant",
  parts: [{ type: "text", text: WELCOME_TEXT }],
};

function getMessageText(message: UIMessage): string {
  return message.parts
    .filter((part) => part.type === "text")
    .map((part) => (part as { text: string }).text)
    .join("");
}

export function AiChat() {
  const [open, setOpen] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const chatTransport = new DefaultChatTransport({ api: "/api/chat" });
  const { messages, sendMessage, status, error } = useChat({
    id: "money-power-assistant",
    messages: [WELCOME_MESSAGE],
    transport: chatTransport,
  });

  const isLoading = status === "submitted" || status === "streaming";


  useEffect(() => {
    if (open) {
      textareaRef.current?.focus();
    }
  }, [open, status]);

  const handleSubmit = async (
    message: { text: string; files: unknown[] },
    _event: FormEvent<HTMLFormElement>,
  ) => {
    const text = message.text.trim();
    if (!text) return;
    await sendMessage({ text });
  };

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Open AI assistant"
        className={cn(
          "fixed bottom-6 left-6 z-50 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-glow transition hover:scale-105",
          open && "hidden",
        )}
      >
        <Bot className="h-6 w-6" />
      </button>

      {open && (
        <div className="fixed bottom-6 left-6 z-50 flex h-[min(680px,calc(100vh-120px))] w-[min(380px,calc(100vw-48px))] flex-col overflow-hidden rounded-3xl glass shadow-glow animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-center justify-between border-b border-border/60 px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-primary text-primary-foreground">
                <Bot className="h-4 w-4" />
              </div>
              <div>
                <p className="text-sm font-semibold">Subscription Fighters Assistant</p>
                <p className="text-xs text-muted-foreground">Ask me anything</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon-sm"
              onClick={() => setOpen(false)}
              aria-label="Close chat"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <Conversation className="flex-1">
            <ConversationContent>
              {messages.length === 0 ? (
                <ConversationEmptyState
                  icon={<Bot className="h-8 w-8" />}
                  title="No messages yet"
                  description="Ask about our services, prices, or order status."
                />
              ) : (
                messages.map((message) => (
                  <Message key={message.id} from={message.role}>
                    <MessageContent>
                      <MessageResponse key={`${message.id}-${getMessageText(message).length}`}>
                        {getMessageText(message)}
                      </MessageResponse>
                    </MessageContent>
                  </Message>
                ))
              )}
            </ConversationContent>
            <ConversationScrollButton />
          </Conversation>

          {error && (
            <div className="px-4 py-2 text-xs text-destructive">
              Something went wrong. Please try again.
            </div>
          )}

          <PromptInput onSubmit={handleSubmit} className="border-t border-border/60 p-3">
            <PromptInputTextarea
              ref={textareaRef}
              placeholder="Ask about services, prices, orders..."
              disabled={isLoading}
            />
            <PromptInputFooter className="justify-end pt-2">
              <PromptInputSubmit
                status={status}
                disabled={isLoading}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              />
            </PromptInputFooter>
          </PromptInput>
        </div>
      )}
    </>
  );
}
