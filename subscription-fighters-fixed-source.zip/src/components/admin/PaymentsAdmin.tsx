import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, Save, ExternalLink, Check, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";

export function PaymentsAdmin() {
  return (
    <div className="space-y-6">
      <AccountsEditor />
      <ProofsList />
    </div>
  );
}

function AccountsEditor() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "payment-accounts"],
    queryFn: async () => {
      const { data } = await supabase.from("payment_accounts").select("*").order("label");
      return data ?? [];
    },
  });

  if (isLoading) return <div className="glass grid h-32 place-items-center rounded-2xl"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>;

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {(data ?? []).map((a: any) => <AccountCard key={a.id} account={a} onSaved={() => qc.invalidateQueries({ queryKey: ["admin", "payment-accounts"] })} />)}
    </div>
  );
}

function AccountCard({ account, onSaved }: { account: any; onSaved: () => void }) {
  const [form, setForm] = useState({
    account_title: account.account_title ?? "",
    account_number: account.account_number ?? "",
    instructions: account.instructions ?? "",
    active: !!account.active,
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from("payment_accounts").update({
      account_title: form.account_title.trim(),
      account_number: form.account_number.trim(),
      instructions: form.instructions.trim() || null,
      active: form.active,
    }).eq("id", account.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(`${account.label} updated`);
    onSaved();
  };

  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <h3 className="font-bold">{account.label}</h3>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          Active <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
        </div>
      </div>
      <div className="mt-3 space-y-3">
        <div>
          <Label>Account title</Label>
          <Input value={form.account_title} onChange={(e) => setForm({ ...form, account_title: e.target.value })} />
        </div>
        <div>
          <Label>Account number</Label>
          <Input value={form.account_number} onChange={(e) => setForm({ ...form, account_number: e.target.value })} placeholder="03XX XXXXXXX" />
        </div>
        <div>
          <Label>Instructions (optional)</Label>
          <Textarea rows={2} value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} />
        </div>
        <Button onClick={save} disabled={saving} className="rounded-full">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Save className="mr-1 h-4 w-4" /> Save</>}
        </Button>
      </div>
    </div>
  );
}

function ProofsList() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "payment-proofs"],
    queryFn: async () => {
      const { data: proofs } = await supabase.from("payment_proofs").select("*").order("created_at", { ascending: false });
      const uIds = Array.from(new Set((proofs ?? []).map((p: any) => p.user_id)));
      const { data: profs } = uIds.length
        ? await supabase.from("profiles").select("id,email,full_name").in("id", uIds)
        : { data: [] as any[] };
      const map = new Map((profs ?? []).map((p: any) => [p.id, p]));
      return (proofs ?? []).map((p: any) => ({ ...p, profile: map.get(p.user_id) }));
    },
  });

  const review = async (p: any, status: "verified" | "rejected") => {
    const { error } = await supabase.from("payment_proofs").update({ status }).eq("id", p.id);
    if (error) return toast.error(error.message);
    if (status === "verified") await supabase.from("orders").update({ status: "paid" }).eq("id", p.order_id);
    toast.success(status === "verified" ? "Payment verified, order marked paid" : "Payment rejected");
    qc.invalidateQueries({ queryKey: ["admin", "payment-proofs"] });
    qc.invalidateQueries({ queryKey: ["admin", "orders"] });
  };

  if (isLoading) return <div className="glass grid h-32 place-items-center rounded-2xl"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>;
  if (!data?.length) return <div className="glass rounded-2xl p-8 text-center text-muted-foreground">No payment proofs submitted yet.</div>;

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {data.map((p: any) => <ProofCard key={p.id} p={p} onReview={review} />)}
    </div>
  );
}

function ProofCard({ p, onReview }: { p: any; onReview: (p: any, s: "verified" | "rejected") => void }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    supabase.storage.from("payment-proofs").createSignedUrl(p.screenshot_path, 3600).then(({ data }) => {
      if (active) setUrl(data?.signedUrl ?? null);
    });
    return () => { active = false; };
  }, [p.screenshot_path]);

  const cls = p.status === "verified"
    ? "border-emerald-200 bg-emerald-100 text-emerald-800"
    : p.status === "rejected"
    ? "border-rose-200 bg-rose-100 text-rose-800"
    : "border-amber-200 bg-amber-100 text-amber-800";

  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="font-mono text-xs">order #{String(p.order_id).slice(0, 8)}</div>
        <Badge variant="outline" className={cls}>{p.status}</Badge>
      </div>
      <div className="mt-2 text-sm">
        <div className="font-semibold capitalize">{p.method} · ${Number(p.amount ?? 0).toFixed(2)}</div>
        <div className="text-muted-foreground">{p.sender_name} · <span className="font-mono">{p.sender_number}</span></div>
        {p.transaction_id && <div className="text-muted-foreground">TID: <span className="font-mono">{p.transaction_id}</span></div>}
        <div className="text-xs text-muted-foreground">{p.profile?.email} · {new Date(p.created_at).toLocaleString()}</div>
      </div>
      {url && (
        <a href={url} target="_blank" rel="noreferrer" className="mt-3 block overflow-hidden rounded-xl border border-border/60">
          <img src={url} alt="Payment screenshot" className="max-h-56 w-full bg-muted object-contain" />
          <div className="flex items-center gap-1 p-2 text-xs text-muted-foreground"><ExternalLink className="h-3 w-3" /> Open full size</div>
        </a>
      )}
      {p.status === "submitted" && (
        <div className="mt-3 flex gap-2">
          <Button size="sm" className="rounded-full bg-emerald-500 hover:bg-emerald-500/90" onClick={() => onReview(p, "verified")}>
            <Check className="mr-1 h-4 w-4" /> Verify
          </Button>
          <Button size="sm" variant="outline" className="rounded-full" onClick={() => onReview(p, "rejected")}>
            <X className="mr-1 h-4 w-4" /> Reject
          </Button>
        </div>
      )}
    </div>
  );
}
