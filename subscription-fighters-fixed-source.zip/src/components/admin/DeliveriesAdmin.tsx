import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Send, CheckCircle2, XCircle, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { sendDeliveryEmail } from "@/lib/delivery.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";

const DEFAULT_INSTRUCTIONS = `Log in with the email and password given above.
If you are asked for a verification code, message us on WhatsApp and we will send it.
Warranty is valid for the full duration of your plan.`;

const emptyForm = {
  customerEmail: "",
  customerName: "",
  serviceName: "",
  accountEmail: "",
  accountPassword: "",
  deliveryTime: "",
  duration: "",
  instructions: DEFAULT_INSTRUCTIONS,
  amount: "",
};

export function DeliveriesAdmin() {
  const qc = useQueryClient();
  const send = useServerFn(sendDeliveryEmail);
  const [form, setForm] = useState(emptyForm);
  const [sending, setSending] = useState(false);

  const set = (k: keyof typeof emptyForm) => (e: { target: { value: string } }) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const { data: products } = useQuery({
    queryKey: ["admin", "products-names"],
    queryFn: async () => {
      const { data } = await supabase.from("products").select("id,name").order("name");
      return data ?? [];
    },
  });

  const { data: history, isLoading } = useQuery({
    queryKey: ["admin", "deliveries"],
    queryFn: async () => {
      const { data } = await supabase
        .from("deliveries")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      return data ?? [];
    },
  });

  const submit = async () => {
    if (!form.customerEmail.trim() || !/^\S+@\S+\.\S+$/.test(form.customerEmail.trim()))
      return toast.error("Enter a valid customer email");
    if (!form.serviceName.trim()) return toast.error("Enter the service name");
    if (!form.accountEmail.trim() || !form.accountPassword.trim())
      return toast.error("Enter the account email and password to deliver");

    setSending(true);
    try {
      const res = await send({
        data: {
          customerEmail: form.customerEmail.trim(),
          customerName: form.customerName.trim(),
          serviceName: form.serviceName.trim(),
          accountEmail: form.accountEmail.trim(),
          accountPassword: form.accountPassword.trim(),
          deliveryTime: form.deliveryTime.trim(),
          duration: form.duration.trim(),
          instructions: form.instructions.trim(),
          ...(form.amount.trim() ? { amount: Number(form.amount) } : {}),
        },
      });
      toast.success(`Delivered — Order ID ${res.orderCode}`);
      setForm(emptyForm);
      qc.invalidateQueries({ queryKey: ["admin", "deliveries"] });
    } catch (e: any) {
      toast.error(e?.message ?? "Could not send the email");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="glass rounded-2xl p-5">
        <div className="flex items-center gap-2">
          <Send className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-bold">Deliver an order by email</h3>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Fill in the customer's email and the account credentials. We generate an Order ID and send a branded email with credentials, delivery time and instructions.
        </p>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div>
            <Label htmlFor="d-cemail">Customer email</Label>
            <Input id="d-cemail" value={form.customerEmail} onChange={set("customerEmail")} placeholder="customer@gmail.com" />
          </div>
          <div>
            <Label htmlFor="d-cname">Customer name (optional)</Label>
            <Input id="d-cname" value={form.customerName} onChange={set("customerName")} placeholder="Ali Khan" />
          </div>
          <div>
            <Label htmlFor="d-service">Service</Label>
            <Input id="d-service" value={form.serviceName} onChange={set("serviceName")} placeholder="Netflix Premium" list="d-products" />
            <datalist id="d-products">
              {(products ?? []).map((p: any) => <option key={p.id} value={p.name} />)}
            </datalist>
          </div>
          <div>
            <Label htmlFor="d-duration">Duration</Label>
            <Input id="d-duration" value={form.duration} onChange={set("duration")} placeholder="1 Month" />
          </div>
          <div>
            <Label htmlFor="d-aemail">Account email to deliver</Label>
            <Input id="d-aemail" value={form.accountEmail} onChange={set("accountEmail")} placeholder="login@example.com" />
          </div>
          <div>
            <Label htmlFor="d-apass">Account password</Label>
            <Input id="d-apass" value={form.accountPassword} onChange={set("accountPassword")} placeholder="Password123" />
          </div>
          <div>
            <Label htmlFor="d-time">Delivery / validity time</Label>
            <Input id="d-time" value={form.deliveryTime} onChange={set("deliveryTime")} placeholder="Valid until 23 Oct 2026" />
          </div>
          <div>
            <Label htmlFor="d-amount">Amount paid in USD (optional)</Label>
            <Input id="d-amount" value={form.amount} onChange={set("amount")} placeholder="4.99" inputMode="decimal" />
          </div>
        </div>

        <div className="mt-3">
          <Label htmlFor="d-inst">Instructions (one per line)</Label>
          <Textarea id="d-inst" rows={4} value={form.instructions} onChange={set("instructions")} />
        </div>

        <Button onClick={submit} disabled={sending} size="lg" className="mt-4 w-full rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Send className="mr-1 h-4 w-4" /> Send delivery email</>}
        </Button>
      </div>

      <div className="glass rounded-2xl p-5">
        <h3 className="text-lg font-bold">Sent deliveries</h3>
        {isLoading ? (
          <div className="grid h-24 place-items-center"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
        ) : (history ?? []).length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">Nothing delivered yet.</p>
        ) : (
          <div className="mt-3 space-y-2">
            {(history ?? []).map((d: any) => (
              <div key={d.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border/60 bg-background/60 p-3 text-sm">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold">{d.order_code}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 gap-1 px-2 text-xs"
                      onClick={() => navigator.clipboard.writeText(d.order_code).then(() => toast.success("Order ID copied"), () => toast.error("Copy failed"))}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {d.service_name} → {d.customer_email}
                    {d.delivery_time ? ` · ${d.delivery_time}` : ""}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{new Date(d.created_at).toLocaleString()}</span>
                  {d.status === "sent" ? (
                    <Badge variant="outline" className="border-emerald-200 bg-emerald-100 text-emerald-800"><CheckCircle2 className="mr-1 h-3 w-3" /> Sent</Badge>
                  ) : (
                    <Badge variant="outline" className="border-rose-200 bg-rose-100 text-rose-800"><XCircle className="mr-1 h-3 w-3" /> Failed</Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
