import { useState } from "react";
import { MessageCircle, Instagram, Send, X, Headset } from "lucide-react";
import { contactLinks } from "@/lib/contact";
import { useBuyIntent } from "@/lib/buyIntent";

export function FloatingContact({ productName }: { productName?: string }) {
  const [open, setOpen] = useState(false);
  const buy = useBuyIntent();
  const c = buy
    ? contactLinks(buy.intent.productName ?? productName, {
        quantity: buy.intent.quantity,
        unitPrice: buy.intent.unitPrice,
        total: buy.intent.total,
        couponCode: buy.intent.couponCode,
        couponPercent: buy.intent.couponPercent,
        couponExpiresAt: buy.intent.couponExpiresAt,
      })
    : contactLinks(productName);


  const items = [
    { href: c.whatsapp, label: "WhatsApp", Icon: MessageCircle, bg: "bg-emerald-500" },
    { href: c.instagram, label: "Instagram", Icon: Instagram, bg: "bg-pink-500" },
    { href: c.telegram, label: "Telegram", Icon: Send, bg: "bg-sky-500" },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {open && items.map((it, i) => (
        <a
          key={it.label}
          href={it.href}
          target="_blank"
          rel="noreferrer"
          style={{ animationDelay: `${i * 60}ms` }}
          className={`animate-fade-up group flex items-center gap-2 rounded-full ${it.bg} pl-3 pr-4 py-2 text-white shadow-glow transition hover:scale-105`}
        >
          <it.Icon className="h-5 w-5" />
          <span className="text-sm font-medium">{it.label}</span>
        </a>
      ))}
      <button
        onClick={() => setOpen(v => !v)}
        aria-label="Contact us"
        className="grid h-14 w-14 place-items-center rounded-full bg-[image:var(--gradient-hero)] text-white shadow-glow transition hover:scale-105"
      >
        {open ? <X className="h-6 w-6" /> : <Headset className="h-6 w-6" />}
      </button>
    </div>
  );
}
