import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type CurrencyCode =
  | "USD" | "PKR" | "INR" | "EUR" | "GBP" | "AED" | "SAR" | "CAD" | "AUD"
  | "BDT" | "NGN" | "ZAR" | "TRY" | "BRL" | "PHP" | "IDR" | "MYR" | "EGP" | "LKR" | "NPR";

type CurrencyInfo = { code: CurrencyCode; symbol: string; rate: number; label: string; locale: string };

// Approximate USD -> local rates. Update as needed.
export const CURRENCIES: Record<CurrencyCode, CurrencyInfo> = {
  USD: { code: "USD", symbol: "$", rate: 1, label: "US Dollar", locale: "en-US" },
  PKR: { code: "PKR", symbol: "Rs", rate: 283, label: "Pakistani Rupee", locale: "en-PK" },
  INR: { code: "INR", symbol: "₹", rate: 88, label: "Indian Rupee", locale: "en-IN" },
  EUR: { code: "EUR", symbol: "€", rate: 0.92, label: "Euro", locale: "de-DE" },
  GBP: { code: "GBP", symbol: "£", rate: 0.79, label: "British Pound", locale: "en-GB" },
  AED: { code: "AED", symbol: "AED ", rate: 3.67, label: "UAE Dirham", locale: "en-AE" },
  SAR: { code: "SAR", symbol: "SAR ", rate: 3.75, label: "Saudi Riyal", locale: "en-SA" },
  CAD: { code: "CAD", symbol: "CA$", rate: 1.37, label: "Canadian Dollar", locale: "en-CA" },
  AUD: { code: "AUD", symbol: "A$", rate: 1.52, label: "Australian Dollar", locale: "en-AU" },
  BDT: { code: "BDT", symbol: "৳", rate: 120, label: "Bangladeshi Taka", locale: "en-BD" },
  NGN: { code: "NGN", symbol: "₦", rate: 1550, label: "Nigerian Naira", locale: "en-NG" },
  ZAR: { code: "ZAR", symbol: "R", rate: 18, label: "South African Rand", locale: "en-ZA" },
  TRY: { code: "TRY", symbol: "₺", rate: 34, label: "Turkish Lira", locale: "tr-TR" },
  BRL: { code: "BRL", symbol: "R$", rate: 5.4, label: "Brazilian Real", locale: "pt-BR" },
  PHP: { code: "PHP", symbol: "₱", rate: 57, label: "Philippine Peso", locale: "en-PH" },
  IDR: { code: "IDR", symbol: "Rp", rate: 16000, label: "Indonesian Rupiah", locale: "id-ID" },
  MYR: { code: "MYR", symbol: "RM", rate: 4.5, label: "Malaysian Ringgit", locale: "ms-MY" },
  EGP: { code: "EGP", symbol: "E£", rate: 48, label: "Egyptian Pound", locale: "en-EG" },
  LKR: { code: "LKR", symbol: "Rs", rate: 300, label: "Sri Lankan Rupee", locale: "en-LK" },
  NPR: { code: "NPR", symbol: "Rs", rate: 140, label: "Nepalese Rupee", locale: "en-NP" },
};

const COUNTRY_TO_CURRENCY: Record<string, CurrencyCode> = {
  US: "USD", PK: "PKR", IN: "INR", GB: "GBP", CA: "CAD", AU: "AUD",
  AE: "AED", SA: "SAR", BD: "BDT", NG: "NGN", ZA: "ZAR", TR: "TRY",
  BR: "BRL", PH: "PHP", ID: "IDR", MY: "MYR", EG: "EGP", LK: "LKR", NP: "NPR",
  DE: "EUR", FR: "EUR", ES: "EUR", IT: "EUR", NL: "EUR", IE: "EUR", PT: "EUR",
  AT: "EUR", BE: "EUR", FI: "EUR", GR: "EUR",
};

const TZ_TO_COUNTRY: Record<string, string> = {
  "Asia/Karachi": "PK",
  "Asia/Kolkata": "IN",
  "Asia/Calcutta": "IN",
  "Asia/Dhaka": "BD",
  "Asia/Dubai": "AE",
  "Asia/Riyadh": "SA",
  "Asia/Colombo": "LK",
  "Asia/Kathmandu": "NP",
  "Asia/Manila": "PH",
  "Asia/Jakarta": "ID",
  "Asia/Kuala_Lumpur": "MY",
  "Africa/Lagos": "NG",
  "Africa/Cairo": "EG",
  "Africa/Johannesburg": "ZA",
  "Europe/London": "GB",
  "Europe/Istanbul": "TR",
  "America/Sao_Paulo": "BR",
  "Australia/Sydney": "AU",
  "Australia/Melbourne": "AU",
};

const STORAGE_KEY = "sf-currency";

function detectFromBrowser(): CurrencyCode {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const country = TZ_TO_COUNTRY[tz] ?? (tz?.startsWith("Europe/") ? "DE" : tz?.startsWith("America/") ? "US" : "");
    if (country && COUNTRY_TO_CURRENCY[country]) return COUNTRY_TO_CURRENCY[country];
    const region = new Intl.Locale(navigator.language).region;
    if (region && COUNTRY_TO_CURRENCY[region]) return COUNTRY_TO_CURRENCY[region];
  } catch {
    /* ignore */
  }
  return "USD";
}

type Ctx = {
  currency: CurrencyInfo;
  setCurrency: (c: CurrencyCode) => void;
  format: (usd: number) => string;
  convert: (usd: number) => number;
};

const CurrencyContext = createContext<Ctx | null>(null);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [code, setCode] = useState<CurrencyCode>("USD");

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY) as CurrencyCode | null;
    if (saved && CURRENCIES[saved]) {
      setCode(saved);
      return;
    }
    setCode(detectFromBrowser());
    // Refine with IP geolocation when available.
    (async () => {
      try {
        const res = await fetch("https://ipapi.co/country/", { signal: AbortSignal.timeout(3000) });
        const country = (await res.text()).trim().toUpperCase();
        const mapped = COUNTRY_TO_CURRENCY[country];
        if (mapped && !localStorage.getItem(STORAGE_KEY)) setCode(mapped);
      } catch {
        /* keep browser detection */
      }
    })();
  }, []);

  const value = useMemo<Ctx>(() => {
    const info = CURRENCIES[code] ?? CURRENCIES.USD;
    const convert = (usd: number) => usd * info.rate;
    const format = (usd: number) => {
      const v = convert(usd);
      const decimals = v >= 1000 || info.rate > 50 ? 0 : 2;
      return `${info.symbol}${v.toLocaleString(info.locale, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      })}`;
    };
    return {
      currency: info,
      setCurrency: (c: CurrencyCode) => {
        setCode(c);
        try { localStorage.setItem(STORAGE_KEY, c); } catch { /* ignore */ }
      },
      format,
      convert,
    };
  }, [code]);

  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrency(): Ctx {
  const ctx = useContext(CurrencyContext);
  if (ctx) return ctx;
  // Safe fallback (e.g. during SSR outside the provider)
  const info = CURRENCIES.USD;
  return {
    currency: info,
    setCurrency: () => {},
    convert: (usd: number) => usd,
    format: (usd: number) => `$${usd.toFixed(2)}`,
  };
}

export function Price({ usd, className }: { usd: number; className?: string }) {
  const { format } = useCurrency();
  return <span className={className}>{format(usd)}</span>;
}
