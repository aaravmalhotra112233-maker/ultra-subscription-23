import { tool } from "ai";
import { z } from "zod";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { contactLinks } from "@/lib/contact";

export function createChatTools(
  supabase: SupabaseClient<Database>,
  userId: string | null,
) {
  return {
    searchProducts: tool({
      description:
        "Search active products/services by name, short description, or category. Returns a list of matching products with name, slug, price, and short description.",
      inputSchema: z.object({
        query: z.string().describe("Search term like 'Netflix', 'AI tool', 'editing'"),
        limit: z.number().max(10).default(5).describe("Max number of results"),
      }),
      execute: async ({ query, limit }) => {
        const { data, error } = await supabase
          .from("products")
          .select("id,name,slug,short_description,price,image_url,featured")
          .eq("active", true)
          .or(`name.ilike.%${query}%,short_description.ilike.%${query}%`)
          .limit(limit);
        if (error) return { error: error.message, results: [] };
        return {
          results: (data ?? []).map((p) => ({
            name: p.name,
            slug: p.slug,
            price: Number(p.price),
            short_description: p.short_description,
            image_url: p.image_url,
            featured: p.featured,
          })),
        };
      },
    }),

    getProductDetails: tool({
      description:
        "Get full details for a product/service by slug. Use this when the user asks about a specific service.",
      inputSchema: z.object({
        slug: z.string().describe("Product slug from the URL or search result"),
      }),
      execute: async ({ slug }) => {
        const { data: product, error } = await supabase
          .from("products")
          .select("*,categories(name,slug)")
          .eq("slug", slug)
          .eq("active", true)
          .maybeSingle();
        if (error) return { error: error.message };
        if (!product) return { notFound: true };

        const { data: reviews } = await supabase
          .from("reviews_public")
          .select("rating,comment,display_name")
          .eq("product_id", product.id)
          .order("created_at", { ascending: false })
          .limit(5);

        return {
          product: {
            name: product.name,
            slug: product.slug,
            price: Number(product.price),
            short_description: product.short_description,
            description: product.description,
            features: product.features ?? [],
            image_url: product.image_url,
            category: (product.categories as { name: string; slug: string } | null)?.name,
            avg_rating: (reviews ?? []).length
              ? (reviews!.reduce((s, r) => s + (r.rating ?? 0), 0) / reviews!.length).toFixed(1)
              : null,
            recent_reviews: (reviews ?? []).map((r) => ({
              rating: r.rating ?? 0,
              comment: r.comment,
              name: r.display_name,
            })),
          },
        };
      },
    }),

    getOrderStatus: tool({
      description:
        "Get the status of a user's order by order ID. Only works for signed-in users and only returns their own orders.",
      inputSchema: z.object({
        orderId: z.string().describe("The order ID (full UUID or first 8 characters)"),
      }),
      execute: async ({ orderId }) => {
        if (!userId) {
          return {
            error:
              "You must be signed in to check order status. Please sign in and try again.",
          };
        }
        const { data, error } = await supabase
          .from("orders")
          .select("id,status,amount,quantity,created_at,products(name,slug)")
          .eq("user_id", userId)
          .ilike("id", `${orderId}%`)
          .maybeSingle();
        if (error) return { error: error.message };
        if (!data) return { notFound: true };
        return {
          order: {
            id: data.id,
            status: data.status,
            amount: Number(data.amount),
            quantity: data.quantity,
            created_at: data.created_at,
            product_name: (data.products as { name: string; slug: string } | null)?.name,
          },
        };
      },
    }),

    getContactInfo: tool({
      description:
        "Return Subscription Fighters contact links and handles. Use when the user asks how to buy, contact, or reach support.",
      inputSchema: z.object({
        productName: z
          .string()
          .optional()
          .describe("Optional product name to pre-fill the message"),
      }),
      execute: async ({ productName }) => {
        const links = contactLinks(productName);
        return {
          whatsapp: links.whatsapp,
          instagram: links.instagram,
          telegram: links.telegram,
          note: "Click WhatsApp for the fastest reply. Mention the service name and any coupon you want to use.",
        };
      },
    }),
  };
}
