// Update these to your real handles. Used across contact buttons.
export const CONTACT = {
  whatsapp: "+224624048804",
  instagram: "aquapress.pk",
  telegram: "zzaibi265",
  email: "zzaibi265@gmail.com",
};

export const contactLinks = (
  productName?: string,
  opts?: {
    quantity?: number;
    unitPrice?: number;
    total?: number;
    couponCode?: string | null;
    couponPercent?: number | null;
    couponExpiresAt?: string | null;
    orderId?: string | null;
  },
) => {
  const qty = opts?.quantity && opts.quantity > 0 ? opts.quantity : undefined;
  const lines: string[] = [];
  if (opts?.orderId) {
    lines.push(`Hi Subscription Fighters! I just placed order #${opts.orderId.slice(0, 8)}.`);
    if (productName) lines.push(`Service: ${productName}`);
  } else if (productName) {
    lines.push(`Hi Subscription Fighters! I'd like to buy "${productName}".`);
  } else {
    lines.push(`Hi Subscription Fighters! I'd like to know more about your services.`);
  }
  if (qty) lines.push(`Quantity: ${qty}`);
  if (typeof opts?.unitPrice === "number") lines.push(`Unit price: $${opts.unitPrice.toFixed(2)}`);
  if (opts?.couponCode) {
    const pct = typeof opts.couponPercent === "number" ? ` (${opts.couponPercent}% off)` : "";
    lines.push(`Coupon: ${opts.couponCode}${pct}`);
    if (opts.couponExpiresAt) {
      const d = new Date(opts.couponExpiresAt);
      if (!isNaN(d.getTime())) lines.push(`Coupon valid until: ${d.toLocaleDateString()}`);
    } else {
      lines.push(`Coupon validity: no expiry`);
    }
  }
  if (typeof opts?.total === "number") lines.push(`Total: $${opts.total.toFixed(2)}`);
  lines.push(
    opts?.orderId
      ? `Please confirm payment details so you can deliver instantly.`
      : `Please share payment details to complete this order.`,
  );

  const msg = encodeURIComponent(lines.join("\n"));
  return {
    whatsapp: `https://wa.me/${CONTACT.whatsapp.replace(/[^\d]/g, "")}?text=${msg}`,
    instagram: `https://instagram.com/${CONTACT.instagram}`,
    telegram: `https://t.me/${CONTACT.telegram}`,
  };
};
