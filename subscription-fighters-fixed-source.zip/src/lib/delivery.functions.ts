import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_mail/gmail/v1";
const FROM_NAME = "Subscription Fighters";
const FROM_EMAIL = "aaravmalhotra112233@gmail.com";
const SUPPORT_WHATSAPP = "https://wa.me/224624048804";

const schema = z.object({
  customerEmail: z.string().email(),
  customerName: z.string().trim().optional().default(""),
  serviceName: z.string().trim().min(1),
  accountEmail: z.string().trim().min(1),
  accountPassword: z.string().trim().min(1),
  deliveryTime: z.string().trim().optional().default(""),
  duration: z.string().trim().optional().default(""),
  instructions: z.string().trim().optional().default(""),
  amount: z.number().optional(),
  orderId: z.string().uuid().optional(),
});

const b64 = (s: string) =>
  btoa(Array.from(new TextEncoder().encode(s), (b) => String.fromCharCode(b)).join(""));
const header = (v: string) => (/^[\x00-\x7F]*$/.test(v) ? v : `=?UTF-8?B?${b64(v)}?=`);
const esc = (v: string) =>
  v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function makeOrderCode() {
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  const stamp = Date.now().toString(36).slice(-4).toUpperCase();
  return `SF-${stamp}${rand}`;
}

function buildHtml(d: {
  orderCode: string;
  customerName: string;
  serviceName: string;
  accountEmail: string;
  accountPassword: string;
  deliveryTime: string;
  duration: string;
  instructions: string;
  amount?: number;
}) {
  const row = (label: string, value: string, mono = false) =>
    value
      ? `<tr><td style="padding:10px 14px;border-bottom:1px solid #e6eef7;color:#5b6b7d;font-size:13px;">${esc(label)}</td>
         <td style="padding:10px 14px;border-bottom:1px solid #e6eef7;color:#0f2438;font-size:14px;font-weight:600;${mono ? "font-family:ui-monospace,Menlo,monospace;" : ""}">${esc(value)}</td></tr>`
      : "";

  const instructionLines = d.instructions
    ? d.instructions
        .split(/\r?\n/)
        .filter((l) => l.trim())
        .map((l) => `<li style="margin:0 0 6px;">${esc(l.trim())}</li>`)
        .join("")
    : "";

  return `<!doctype html><html><body style="margin:0;padding:24px;background:#eef6fd;font-family:Segoe UI,Helvetica,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;background:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 8px 30px rgba(20,80,140,.12);">
    <tr><td style="background:linear-gradient(135deg,#38a3f5,#1d6fd0);padding:28px 24px;text-align:center;color:#fff;">
      <div style="font-size:22px;font-weight:800;letter-spacing:.3px;">SUBSCRIPTION FIGHTERS</div>
      <div style="font-size:13px;opacity:.9;margin-top:6px;">Your order has been delivered</div>
    </td></tr>
    <tr><td style="padding:24px;">
      <p style="margin:0 0 6px;font-size:16px;color:#0f2438;">Hello ${esc(d.customerName || "there")},</p>
      <p style="margin:0 0 18px;font-size:14px;color:#5b6b7d;line-height:1.6;">
        Thank you for your purchase. Your <strong style="color:#0f2438;">${esc(d.serviceName)}</strong> is ready. Below are your order details and login credentials.
      </p>

      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e6eef7;border-radius:12px;overflow:hidden;">
        ${row("Order ID", d.orderCode, true)}
        ${row("Service", d.serviceName)}
        ${row("Duration", d.duration)}
        ${row("Delivery time", d.deliveryTime)}
        ${d.amount != null ? row("Amount paid", `$${d.amount.toFixed(2)}`) : ""}
      </table>

      <div style="margin:20px 0 0;padding:16px;border-radius:12px;background:#f2f9ff;border:1px solid #cfe6fb;">
        <div style="font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:#1d6fd0;font-weight:700;">Your login credentials</div>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:10px;">
          <tr><td style="padding:6px 0;font-size:13px;color:#5b6b7d;width:110px;">Email</td>
              <td style="padding:6px 0;font-size:14px;font-weight:700;color:#0f2438;font-family:ui-monospace,Menlo,monospace;">${esc(d.accountEmail)}</td></tr>
          <tr><td style="padding:6px 0;font-size:13px;color:#5b6b7d;">Password</td>
              <td style="padding:6px 0;font-size:14px;font-weight:700;color:#0f2438;font-family:ui-monospace,Menlo,monospace;">${esc(d.accountPassword)}</td></tr>
        </table>
      </div>

      <div style="margin:20px 0 0;">
        <div style="font-size:12px;text-transform:uppercase;letter-spacing:.6px;color:#1d6fd0;font-weight:700;">Instructions</div>
        <ul style="margin:10px 0 0;padding-left:20px;font-size:14px;color:#33465c;line-height:1.6;">
          ${instructionLines}
          <li style="margin:0 0 6px;">Do not change the account email, password or any account settings.</li>
          <li style="margin:0 0 6px;">Do not share these credentials with anyone.</li>
          <li style="margin:0 0 6px;">Keep this email safe — it is your proof of purchase.</li>
          <li style="margin:0;">Any problem? Message us on WhatsApp with your Order ID and we will fix it.</li>
        </ul>
      </div>

      <div style="text-align:center;margin:26px 0 6px;">
        <a href="${SUPPORT_WHATSAPP}" style="display:inline-block;background:linear-gradient(135deg,#38a3f5,#1d6fd0);color:#fff;text-decoration:none;padding:12px 26px;border-radius:999px;font-weight:700;font-size:14px;">Contact support on WhatsApp</a>
      </div>
    </td></tr>
    <tr><td style="padding:18px 24px;background:#f7fbff;text-align:center;color:#8298ad;font-size:12px;">
      Subscription Fighters · ${esc(FROM_EMAIL)}<br/>This is an automated delivery email, please keep it for your records.
    </td></tr>
  </table>
</body></html>`;
}

function buildText(d: { orderCode: string; serviceName: string; accountEmail: string; accountPassword: string; deliveryTime: string; duration: string; instructions: string }) {
  return [
    `SUBSCRIPTION FIGHTERS — Order delivered`,
    ``,
    `Order ID: ${d.orderCode}`,
    `Service: ${d.serviceName}`,
    d.duration ? `Duration: ${d.duration}` : "",
    d.deliveryTime ? `Delivery time: ${d.deliveryTime}` : "",
    ``,
    `Login email: ${d.accountEmail}`,
    `Password: ${d.accountPassword}`,
    ``,
    `Instructions:`,
    d.instructions,
    `- Do not change the account email or password.`,
    `- Do not share these credentials with anyone.`,
    `- Support on WhatsApp: ${SUPPORT_WHATSAPP}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export const sendDeliveryEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => schema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleError || !isAdmin) throw new Error("Forbidden");

    const lovableKey = process.env["LOVABLE_API_KEY"];
    const connKey = process.env["GOOGLE_MAIL_API_KEY"];
    if (!lovableKey || !connKey) throw new Error("Email account is not connected.");

    const orderCode = makeOrderCode();
    const payload = { ...data, orderCode };
    const subject = `Your ${data.serviceName} is ready — Order ${orderCode}`;
    const boundary = `sf_${Math.random().toString(36).slice(2)}`;

    const raw = [
      `From: ${header(FROM_NAME)} <${FROM_EMAIL}>`,
      `To: ${data.customerEmail}`,
      `Subject: ${header(subject)}`,
      "MIME-Version: 1.0",
      `Content-Type: multipart/alternative; boundary="${boundary}"`,
      "",
      `--${boundary}`,
      'Content-Type: text/plain; charset="UTF-8"',
      "",
      buildText(payload),
      "",
      `--${boundary}`,
      'Content-Type: text/html; charset="UTF-8"',
      "",
      buildHtml(payload),
      "",
      `--${boundary}--`,
      "",
    ].join("\r\n");

    const encoded = b64(raw).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

    const res = await fetch(`${GATEWAY_URL}/users/me/messages/send`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": connKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw: encoded }),
    });

    const body = await res.text();
    const ok = res.ok;

    await context.supabase.from("deliveries").insert({
      order_code: orderCode,
      order_id: data.orderId ?? null,
      customer_email: data.customerEmail,
      customer_name: data.customerName || null,
      service_name: data.serviceName,
      account_email: data.accountEmail,
      account_password: data.accountPassword,
      delivery_time: data.deliveryTime || null,
      duration: data.duration || null,
      instructions: data.instructions || null,
      amount: data.amount ?? null,
      sent_by: context.userId,
      sent_at: ok ? new Date().toISOString() : null,
      status: ok ? "sent" : "failed",
      error: ok ? null : body.slice(0, 500),
    });

    if (!ok) {
      console.error(`Gmail send failed [${res.status}]: ${body}`);
      throw new Error(`Email could not be sent [${res.status}]: ${body.slice(0, 300)}`);
    }

    return { orderCode };
  });
