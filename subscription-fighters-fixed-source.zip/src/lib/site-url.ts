// Public site URL used for auth email confirmation links.
// Preview/sandbox origins can't be opened by users from their inbox,
// so always send confirmation links to the published site.
export const PUBLIC_SITE_URL = "https://subscriptionfighters.lovable.app";

export function authRedirectUrl(path = "/") {
  if (typeof window === "undefined") return `${PUBLIC_SITE_URL}${path}`;
  const origin = window.location.origin;
  const isPreview = origin.includes("id-preview--") || origin.includes("localhost");
  return `${isPreview ? PUBLIC_SITE_URL : origin}${path}`;
}
