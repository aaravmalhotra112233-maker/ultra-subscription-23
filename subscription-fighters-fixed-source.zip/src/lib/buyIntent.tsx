import { createContext, useContext, useState, type ReactNode } from "react";

export type BuyIntent = {
  productName?: string;
  quantity: number;
  unitPrice: number;
  total: number;
  couponCode: string | null;
  couponPercent: number | null;
  couponExpiresAt: string | null;
};

type Ctx = {
  intent: BuyIntent;
  setIntent: (i: Partial<BuyIntent>) => void;
};

const BuyIntentContext = createContext<Ctx | null>(null);

export function BuyIntentProvider({ productName, price, children }: { productName: string; price: number; children: ReactNode }) {
  const [intent, setState] = useState<BuyIntent>({
    productName,
    quantity: 1,
    unitPrice: price,
    total: price,
    couponCode: null,
    couponPercent: null,
    couponExpiresAt: null,
  });
  const setIntent = (patch: Partial<BuyIntent>) => setState((s) => ({ ...s, ...patch }));
  return <BuyIntentContext.Provider value={{ intent, setIntent }}>{children}</BuyIntentContext.Provider>;
}

export function useBuyIntent() {
  return useContext(BuyIntentContext);
}
