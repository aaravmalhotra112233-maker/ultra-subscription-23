import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "sonner";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { ClientOnly } from "@/components/ClientOnly";
import { AiChat } from "@/components/AiChat";
import { CurrencyProvider } from "@/lib/currency";


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Subscription Fighters — Premium Digital Services & AI Tool Subscriptions" },
      { name: "description", content: "Buy premium AI tools, editing software and digital memberships at unbeatable prices. Instant delivery on WhatsApp, Instagram and Telegram." },
      { name: "author", content: "Subscription Fighters" },
      { name: "theme-color", content: "#3ea6ff" },
      { property: "og:title", content: "Subscription Fighters — Premium Digital Services & AI Tool Subscriptions" },
      { property: "og:description", content: "Buy premium AI tools, editing software and digital memberships at unbeatable prices. Instant delivery on WhatsApp, Instagram and Telegram." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Subscription Fighters" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Subscription Fighters — Premium Digital Services & AI Tool Subscriptions" },
      { name: "twitter:description", content: "Buy premium AI tools, editing software and digital memberships at unbeatable prices. Instant delivery on WhatsApp, Instagram and Telegram." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/EIn8wpkrzsaDJ654oV6RHESGnwP2/social-images/social-1783527787044-Gemini_Generated_Image_efis4cefis4cefis.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/EIn8wpkrzsaDJ654oV6RHESGnwP2/social-images/social-1783527787044-Gemini_Generated_Image_efis4cefis4cefis.webp" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.png", type: "image/png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <CurrencyProvider>
        <Outlet />
        <Toaster position="top-right" richColors />
        <ClientOnly>
          <AiChat />
        </ClientOnly>
      </CurrencyProvider>
    </QueryClientProvider>

  );
}
