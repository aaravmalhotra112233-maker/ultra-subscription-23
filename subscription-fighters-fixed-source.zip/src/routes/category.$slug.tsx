import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Tag } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FloatingContact } from "@/components/FloatingContact";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type CategoryPage = {
  category: { id: string; name: string; slug: string };
  products: ProductCardData[];
};

export const Route = createFileRoute("/category/$slug")({
  head: ({ params, loaderData }) => {
    const data = loaderData as CategoryPage | undefined;
    const name = data?.category.name ?? params.slug;
    const title = `${name} — Subscription Fighters`;
    const description = data
      ? `Browse ${data.products.length} ${name.toLowerCase()} services on Subscription Fighters. Instant delivery via WhatsApp, Telegram and Instagram.`
      : `Browse ${name} services on Subscription Fighters.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { property: "og:url", content: `/category/${params.slug}` },
      ],
      links: [{ rel: "canonical", href: `/category/${params.slug}` }],
    };
  },
  loader: async ({ params }): Promise<CategoryPage> => {
    const { data: category } = await supabase
      .from("categories")
      .select("id,name,slug")
      .eq("slug", params.slug)
      .maybeSingle();
    if (!category) throw notFound();
    const { data: products } = await supabase
      .from("products")
      .select("id,name,slug,short_description,price,image_url,featured")
      .eq("active", true)
      .eq("category_id", category.id)
      .order("created_at", { ascending: false });
    return { category, products: (products ?? []) as ProductCardData[] };
  },
  component: CategoryPageView,
  notFoundComponent: () => (
    <div>
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="text-4xl font-bold">Category not found</h1>
        <p className="mt-3 text-muted-foreground">This category doesn't exist or has been removed.</p>
        <Button asChild className="mt-6"><Link to="/services">Browse all services</Link></Button>
      </main>
      <Footer />
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-3xl px-4 py-24 text-center">
      <h1 className="text-2xl font-bold">Something went wrong</h1>
      <p className="mt-3 text-muted-foreground">{error.message}</p>
    </div>
  ),
});

function CategoryPageView() {
  const { slug } = Route.useParams();
  const initial = Route.useLoaderData();

  const { data } = useQuery({
    queryKey: ["category", slug],
    initialData: initial,
    queryFn: async () => {
      const { data: category } = await supabase
        .from("categories")
        .select("id,name,slug")
        .eq("slug", slug)
        .maybeSingle();
      if (!category) throw notFound();
      const { data: products } = await supabase
        .from("products")
        .select("id,name,slug,short_description,price,image_url,featured")
        .eq("active", true)
        .eq("category_id", category.id)
        .order("created_at", { ascending: false });
      return { category, products: (products ?? []) as ProductCardData[] };
    },
  });

  const { category, products } = data as CategoryPage;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: `${category.name} — Subscription Fighters`,
    hasPart: products.slice(0, 12).map((p: ProductCardData) => ({
      "@type": "Product",
      name: p.name,
      url: `/product/${p.slug}`,
      image: p.image_url ?? undefined,
      offers: { "@type": "Offer", price: Number(p.price), priceCurrency: "USD" },
    })),
  };

  return (
    <div>
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-10">
        <Link to="/services" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> All services
        </Link>
        <div className="mt-4 flex flex-col gap-2">
          <Badge variant="secondary" className="w-max gap-1"><Tag className="h-3 w-3" /> Category</Badge>
          <h1 className="text-4xl font-bold tracking-tight md:text-5xl">{category.name}</h1>
          <p className="text-muted-foreground">
            {products.length === 0
              ? "No services in this category yet."
              : `${products.length} service${products.length === 1 ? "" : "s"} available.`}
          </p>
        </div>

        <div className="mt-8">
          {products.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-12 text-center text-muted-foreground">
              Nothing here yet — check back soon.
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {products.map((p: ProductCardData) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </div>

        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
