import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { MessageCircle, Instagram, Send, Mail, Clock, MapPin, Loader2 } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FloatingContact } from "@/components/FloatingContact";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { contactLinks, CONTACT } from "@/lib/contact";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Subscription Fighters — Chat with Support 24/7" },
      { name: "description", content: "Get in touch with Subscription Fighters on WhatsApp, Instagram or Telegram. 24/7 support for orders, custom bundles and questions." },
      { property: "og:title", content: "Contact Subscription Fighters" },
      { property: "og:description", content: "Reach us on WhatsApp, Instagram or Telegram — we reply within minutes." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

const messageSchema = z.object({
  name: z.string().trim().min(1, "Name required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  message: z.string().trim().min(5, "Message too short").max(2000),
});

function ContactPage() {
  const c = contactLinks();
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sending, setSending] = useState(false);

  const send = () => {
    const parsed = messageSchema.safeParse(form);
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setSending(true);
    const text = `Hi Subscription Fighters! I'm ${parsed.data.name} (${parsed.data.email}).\n\n${parsed.data.message}`;
    const url = `https://wa.me/${CONTACT.whatsapp.replace(/[^\d]/g, "")}?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank", "noopener,noreferrer");
    setSending(false);
    toast.success("Opening WhatsApp to send your message...");
    setForm({ name: "", email: "", message: "" });
  };

  const channels = [
    { Icon: MessageCircle, name: "WhatsApp", handle: CONTACT.whatsapp, href: c.whatsapp, tint: "bg-emerald-500" },
    { Icon: Instagram, name: "Instagram", handle: `@${CONTACT.instagram}`, href: c.instagram, tint: "bg-pink-500" },
    { Icon: Send, name: "Telegram", handle: `@${CONTACT.telegram}`, href: c.telegram, tint: "bg-sky-500" },
  ];

  return (
    <div>
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-14 md:py-20">
        <div className="text-center">
          <h1 className="text-4xl font-bold tracking-tight md:text-5xl">Let's talk</h1>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">Order questions, custom bundles, partnerships — we reply on any channel within minutes.</p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {channels.map((ch) => (
            <a
              key={ch.name}
              href={ch.href}
              target="_blank"
              rel="noopener noreferrer"
              className="glass group rounded-2xl p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-glow"
            >
              <div className={`grid h-11 w-11 place-items-center rounded-xl text-white shadow-glow ${ch.tint}`}>
                <ch.Icon className="h-5 w-5" />
              </div>
              <div className="mt-4 text-lg font-semibold">{ch.name}</div>
              <div className="mt-1 text-sm text-muted-foreground">{ch.handle}</div>
              <div className="mt-4 text-sm font-medium text-primary group-hover:underline">Start a chat →</div>
            </a>
          ))}
        </div>

        <div className="mt-14 grid gap-10 md:grid-cols-5">
          <div className="md:col-span-3 glass rounded-3xl p-6 md:p-8">
            <h2 className="text-2xl font-bold">Send us a message</h2>
            <p className="mt-1 text-sm text-muted-foreground">We'll open WhatsApp with your message pre-filled — the fastest way to reach us.</p>
            <div className="mt-6 grid gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>Name</Label>
                  <Input maxLength={100} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
                </div>
                <div>
                  <Label>Email</Label>
                  <Input type="email" maxLength={255} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
                </div>
              </div>
              <div>
                <Label>Message</Label>
                <Textarea rows={5} maxLength={2000} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="What can we help with?" />
              </div>
              <Button onClick={send} disabled={sending} size="lg" className="rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send via WhatsApp"}
              </Button>
            </div>
          </div>

          <div className="md:col-span-2 space-y-4">
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Clock className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold">Support hours</div>
                  <div className="text-sm text-muted-foreground">24/7 · Fastest on WhatsApp</div>
                </div>
              </div>
            </div>
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><Mail className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold">Business & partnerships</div>
                  <div className="text-sm text-muted-foreground">DM us on Instagram or Telegram</div>
                </div>
              </div>
            </div>
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><MapPin className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold">Global service</div>
                  <div className="text-sm text-muted-foreground">Digital delivery worldwide</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
