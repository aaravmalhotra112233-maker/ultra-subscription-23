import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Shield, Zap, Users, Heart, Rocket } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FloatingContact } from "@/components/FloatingContact";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Subscription Fighters — Premium Digital Marketplace" },
      { name: "description", content: "Subscription Fighters is a trusted marketplace for premium AI tools, editing software and digital memberships — built for creators, students and small teams." },
      { property: "og:title", content: "About Subscription Fighters" },
      { property: "og:description", content: "Who we are and why creators trust Subscription Fighters for premium digital services." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  const values = [
    { Icon: Zap, title: "Speed", desc: "Instant delivery — most orders fulfilled within minutes on WhatsApp or Telegram." },
    { Icon: Shield, title: "Trust", desc: "Verified suppliers only. Every subscription comes with a working guarantee." },
    { Icon: Heart, title: "Fair pricing", desc: "Prices designed for students, freelancers and creators — never marked up." },
    { Icon: Rocket, title: "Curation", desc: "We only list the tools we'd use ourselves. No bloat, no clutter." },
  ];

  return (
    <div>
      <Navbar />
      <main>
        <section className="mx-auto max-w-4xl px-4 pt-16 pb-10 text-center md:pt-24">
          <div className="glass mx-auto inline-flex animate-fade-up items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-primary">
            <Sparkles className="h-3.5 w-3.5" /> Our story
          </div>
          <h1 className="mt-6 text-4xl font-bold tracking-tight md:text-6xl">
            Building the <span className="gradient-text">creator's toolkit</span>, one service at a time.
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-muted-foreground md:text-lg">
            Subscription Fighters started as a side hustle helping friends get affordable AI subscriptions.
            Today we're a full marketplace serving thousands of creators, students and small teams around the world.
          </p>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-14 md:py-20">
          <div className="grid gap-10 md:grid-cols-2 md:items-center">
            <div className="glass rounded-3xl p-8 shadow-soft">
              <Users className="h-10 w-10 text-primary" />
              <h2 className="mt-4 text-2xl font-bold">Who we serve</h2>
              <p className="mt-3 text-muted-foreground">
                Students unlocking premium learning tools. Freelancers scaling their client work.
                Content creators building faster. Small teams stretching every dollar. If it makes you more productive,
                we probably sell it.
              </p>
            </div>
            <div>
              <h3 className="text-3xl font-bold tracking-tight">Why we exist</h3>
              <p className="mt-4 text-muted-foreground">
                Premium software shouldn't only be for people with corporate budgets. We negotiate directly with suppliers
                and pass the savings on — so anyone can access the same tools the pros use.
              </p>
              <ul className="mt-6 space-y-3 text-sm">
                <li className="flex items-start gap-2"><span className="mt-2 h-2 w-2 rounded-full bg-primary" /> 24/7 chat support on WhatsApp, Instagram, Telegram.</li>
                <li className="flex items-start gap-2"><span className="mt-2 h-2 w-2 rounded-full bg-primary" /> Replacement or refund policy on every purchase.</li>
                <li className="flex items-start gap-2"><span className="mt-2 h-2 w-2 rounded-full bg-primary" /> New tools added every week based on what customers ask for.</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-14 md:py-20">
          <h2 className="text-center text-3xl font-bold tracking-tight md:text-4xl">Our values</h2>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {values.map(({ Icon, title, desc }) => (
              <div key={title} className="glass rounded-2xl p-6 transition hover:-translate-y-1 hover:shadow-glow">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-[image:var(--gradient-hero)] text-white shadow-glow">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 text-lg font-semibold">{title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 pb-20">
          <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-hero)] px-6 py-14 text-center text-white shadow-glow md:py-20">
            <h2 className="text-3xl font-bold tracking-tight md:text-5xl">Ready to try Subscription Fighters?</h2>
            <p className="mx-auto mt-3 max-w-xl text-white/90">Explore our catalog or chat with us for a custom bundle.</p>
            <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button asChild size="lg" variant="secondary" className="rounded-full px-7"><Link to="/services">Browse services</Link></Button>
              <Button asChild size="lg" variant="outline" className="rounded-full border-white/40 bg-white/10 px-7 text-white hover:bg-white/20"><Link to="/contact">Contact us</Link></Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
