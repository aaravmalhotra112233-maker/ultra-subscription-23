import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Bot, Sparkles, Shield, Zap, Star, PlayCircle, Check, Clock, BadgeCheck, Headset } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FloatingContact } from "@/components/FloatingContact";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Subscription Fighters — Premium Digital Services & AI Tool Subscriptions" },
      { name: "description", content: "Buy premium AI tools, editing software and digital memberships at unbeatable prices. Instant delivery on WhatsApp, Instagram and Telegram." },
      { property: "og:title", content: "Subscription Fighters — Premium Digital Services & AI Tool Subscriptions" },
      { property: "og:description", content: "Buy premium AI tools, editing software and digital memberships at unbeatable prices. Instant delivery on WhatsApp, Instagram and Telegram." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Home,
});

function Home() {
  const { data: featured } = useQuery({
    queryKey: ["products", "featured"],
    queryFn: async () => {
      const { data } = await supabase.from("products")
        .select("id,name,slug,short_description,price,image_url,featured")
        .eq("active", true).eq("featured", true).limit(6);
      return (data ?? []) as ProductCardData[];
    },
  });
  const { data: popular } = useQuery({
    queryKey: ["products", "popular"],
    queryFn: async () => {
      const { data } = await supabase.from("products")
        .select("id,name,slug,short_description,price,image_url,featured")
        .eq("active", true).order("created_at", { ascending: false }).limit(6);
      return (data ?? []) as ProductCardData[];
    },
  });

  return (
    <div>
      <Navbar />
      <main>
        <Hero />
        <TrustBar />
        <Section id="featured" title="Featured services" subtitle="Handpicked premium tools our customers love.">
          <Grid items={featured} />
        </Section>
        <Section id="popular" title="Popular right now" subtitle="Trending digital services this week.">
          <Grid items={popular} />
        </Section>
        <WhyUs />
        <Testimonials />
        <CTA />
        <FAQ />
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}

function TrustBar() {
  const items = [
    { Icon: Zap, label: "Instant delivery" },
    { Icon: BadgeCheck, label: "Verified & guaranteed" },
    { Icon: Headset, label: "24/7 chat support" },
    { Icon: Clock, label: "Money-back promise" },
  ];
  return (
    <section className="mx-auto max-w-6xl px-4 -mt-6 md:-mt-10">
      <div className="glass flex flex-wrap items-center justify-around gap-3 rounded-2xl px-4 py-3 text-xs font-medium md:text-sm">
        {items.map(({ Icon, label }) => (
          <div key={label} className="flex items-center gap-2 text-foreground/80">
            <Icon className="h-4 w-4 text-primary" />
            {label}
          </div>
        ))}
      </div>
    </section>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden px-4 pt-16 pb-24 md:pt-24 md:pb-32">
      <div className="mx-auto max-w-6xl text-center">
        <div className="glass mx-auto inline-flex animate-fade-up items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-primary">
          <Sparkles className="h-3.5 w-3.5" /> Premium digital marketplace
        </div>
        <h1 className="mt-6 animate-fade-up text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
          Unlock the tools that <span className="gradient-text">power creators</span>.
        </h1>
        <p className="mx-auto mt-6 max-w-2xl animate-fade-up text-base text-muted-foreground md:text-lg">
          AI subscriptions, editing suites and digital memberships — delivered instantly.
          Built for students, freelancers, content creators and small teams.
        </p>
        <div className="mt-8 flex animate-fade-up flex-col items-center justify-center gap-3 sm:flex-row">
          <Button asChild size="lg" className="rounded-full bg-[image:var(--gradient-hero)] px-7 shadow-glow hover:opacity-95">
            <Link to="/services">Browse services <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="rounded-full px-7">
            <a href="#featured"><PlayCircle className="mr-1 h-4 w-4" /> See how it works</a>
          </Button>
        </div>
        <div className="mt-10 grid animate-fade-up grid-cols-3 gap-4 text-sm text-muted-foreground md:mt-14">
          {[
            ["5k+", "Happy customers"],
            ["50+", "Digital services"],
            ["24/7", "Chat support"],
          ].map(([n, l]) => (
            <div key={l} className="glass rounded-2xl p-4">
              <div className="text-2xl font-bold gradient-text md:text-3xl">{n}</div>
              <div className="mt-1 text-xs md:text-sm">{l}</div>
            </div>
          ))}
        </div>
      </div>

      <div aria-hidden className="pointer-events-none absolute -top-24 left-1/2 -z-10 h-[400px] w-[900px] -translate-x-1/2 rounded-full bg-primary/20 blur-3xl animate-float" />
    </section>
  );
}

function Section({ id, title, subtitle, children }: { id?: string; title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-7xl px-4 py-14 md:py-20">
      <div className="mb-8 flex flex-col items-start justify-between gap-2 md:flex-row md:items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">{title}</h2>
          {subtitle && <p className="mt-2 text-muted-foreground">{subtitle}</p>}
        </div>
        <Link to="/services" className="text-sm font-medium text-primary hover:underline">View all →</Link>
      </div>
      {children}
    </section>
  );
}

function Grid({ items }: { items?: ProductCardData[] }) {
  if (!items) return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="h-72 animate-pulse rounded-2xl bg-muted" />
      ))}
    </div>
  );
  if (items.length === 0) return <div className="rounded-2xl border border-dashed p-12 text-center text-muted-foreground">No services yet. Add them from the admin panel.</div>;
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {items.map(p => <ProductCard key={p.id} p={p} />)}
    </div>
  );
}

function WhyUs() {
  const items = [
    { Icon: Zap, title: "Instant delivery", desc: "Get access within minutes of your order via chat." },
    { Icon: Shield, title: "Secure & trusted", desc: "Verified suppliers, guaranteed working accounts." },
    { Icon: Bot, title: "AI-first catalog", desc: "The latest AI, editing and productivity tools in one place." },
    { Icon: Star, title: "Fair pricing", desc: "Student & creator-friendly prices, no hidden fees." },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 py-14 md:py-20">
      <div className="text-center">
        <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Why choose <span className="gradient-text">Subscription Fighters</span></h2>
        <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">Everything you need to boost your workflow — with the reliability of a premium marketplace.</p>
      </div>
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {items.map(({ Icon, title, desc }) => (
          <div key={title} className="glass group rounded-2xl p-6 transition hover:-translate-y-1 hover:shadow-glow">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-[image:var(--gradient-hero)] text-white shadow-glow">
              <Icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 text-lg font-semibold">{title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Testimonials() {
  const { data: reviews } = useQuery({
    queryKey: ["testimonials"],
    queryFn: async () => {
      const { data } = await supabase
        .from("reviews")
        .select("id,rating,comment,created_at,product_id")
        .gte("rating", 4)
        .not("comment", "is", null)
        .order("rating", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(6);
      const ids = Array.from(new Set((data ?? []).map((r) => r.product_id)));
      const { data: prods } = ids.length
        ? await supabase.from("products").select("id,name,slug").in("id", ids)
        : { data: [] as { id: string; name: string; slug: string }[] };
      const map = new Map((prods ?? []).map((p) => [p.id, p]));
      return (data ?? [])
        .filter((r) => (r.comment ?? "").trim().length > 0)
        .slice(0, 3)
        .map((r) => ({ ...r, product: map.get(r.product_id) }));
    },
  });

  const fallback = [
    { id: "f1", rating: 5, comment: "Got my ChatGPT Plus in 5 minutes. Cheapest deal I've found — support was 10/10.", product: { name: "ChatGPT Plus", slug: "chatgpt-plus-1-month" } },
    { id: "f2", rating: 5, comment: "Bought Adobe & Canva Pro from Subscription Fighters. Legit, fast, and cheaper than direct.", product: { name: "Creative Suite", slug: "" } },
    { id: "f3", rating: 5, comment: "Their bundle deals made semester tools actually affordable. Highly recommend.", product: { name: "Student Bundle", slug: "" } },
  ];
  const items = reviews && reviews.length > 0 ? reviews : fallback;

  return (
    <section className="mx-auto max-w-7xl px-4 py-14 md:py-20">
      <h2 className="text-center text-3xl font-bold tracking-tight md:text-4xl">Loved by creators & students</h2>
      <p className="mx-auto mt-3 max-w-xl text-center text-muted-foreground">Real reviews from verified Subscription Fighters customers.</p>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {items.map((x: any) => (
          <div key={x.id} className="glass rounded-2xl p-6 shadow-soft">
            <div className="flex gap-1 text-primary">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-4 w-4 ${i < x.rating ? "fill-current" : ""}`} />
              ))}
            </div>
            <p className="mt-3 text-sm text-foreground/80">"{x.comment}"</p>
            <div className="mt-4 text-sm font-semibold">
              Verified customer
              {x.product?.name && (
                <span className="font-normal text-muted-foreground"> · {x.product.name}</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="mx-auto max-w-7xl px-4">
      <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-hero)] px-6 py-14 text-center text-white shadow-glow md:py-20">
        <h2 className="text-3xl font-bold tracking-tight md:text-5xl">Ready to level up your stack?</h2>
        <p className="mx-auto mt-3 max-w-xl text-white/90">Browse our catalog or chat with us for a custom bundle tailored to your workflow.</p>
        <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button asChild size="lg" variant="secondary" className="rounded-full px-7"><Link to="/services">Browse services</Link></Button>
          <Button asChild size="lg" variant="outline" className="rounded-full border-white/40 bg-white/10 px-7 text-white hover:bg-white/20"><a href="#faq">Read FAQ</a></Button>
        </div>
        <div aria-hidden className="pointer-events-none absolute -bottom-32 -right-24 h-72 w-72 rounded-full bg-white/20 blur-3xl" />
      </div>
    </section>
  );
}

function FAQ() {
  const faqs = [
    { q: "How do I receive my order?", a: "After you place an order via WhatsApp, Instagram or Telegram, we deliver credentials or an activation link within minutes." },
    { q: "Are these services legit?", a: "Yes — every service comes from verified suppliers with warranty and support." },
    { q: "Can I get a refund?", a: "If a service doesn't work as described, we replace it or refund per our support policy." },
    { q: "Do you offer bundles for teams?", a: "Yes. Chat with us on WhatsApp and we'll craft a custom quote for your team or classroom." },
  ];
  return (
    <section id="faq" className="mx-auto max-w-3xl px-4 py-14 md:py-20">
      <h2 className="text-center text-3xl font-bold tracking-tight md:text-4xl">Frequently asked questions</h2>
      <Accordion type="single" collapsible className="mt-8">
        {faqs.map((f, i) => (
          <AccordionItem key={i} value={`item-${i}`} className="glass mb-3 rounded-2xl px-4">
            <AccordionTrigger className="text-left text-base font-semibold">{f.q}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
      <div className="mt-6 flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <Check className="h-4 w-4 text-primary" /> Still have questions? Reach us on WhatsApp — we reply within minutes.
      </div>
    </section>
  );
}
