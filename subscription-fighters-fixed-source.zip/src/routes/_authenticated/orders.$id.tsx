import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, MessageCircle, Send, Instagram, CheckCircle2, Clock, Package, Truck, Copy } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { contactLinks } from "@/lib/contact";
import { PaymentSubmit } from "@/components/PaymentSubmit";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated/orders/$id")({
  head: () => ({
    meta: [
      { title: "Order Confirmation — Subscription Fighters" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OrderDetail,
});

const STAGES = [
  { key: "pending", label: "Pending", Icon: Clock },
  { key: "paid", label: "Paid", Icon: CheckCircle2 },
  { key: "delivered", label: "Delivered", Icon: Truck },
];

function OrderDetail() {
  const { id } = Route.useParams();
  const router = useRouter();
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ["order", id],
    queryFn: async () => {
      const { data: order } = await supabase
        .from("orders")
        .select("id,amount,status,coupon_code,quantity,created_at,product_id,notes")
        .eq("id", id)
        .maybeSingle();
      if (!order) throw notFound();
      const { data: product } = await supabase
        .from("products")
        .select("id,name,slug,image_url,price")
        .eq("id", order.product_id)
        .maybeSingle();
      return { order, product };
    },
  });

  if (isLoading) {
    return (
      <div>
        <Navbar />
        <main className="mx-auto max-w-3xl px-4 py-12">
          <div className="h-64 animate-pulse rounded-3xl bg-muted" />
        </main>
      </div>
    );
  }

  if (!data) return null;
  const { order, product } = data;
  const currentStage = STAGES.findIndex((s) => s.key === order.status);
  const cancelled = order.status === "cancelled";
  const links = contactLinks(product?.name ?? undefined, {
    quantity: order.quantity ?? 1,
    total: Number(order.amount),
    couponCode: order.coupon_code,
    orderId: order.id,
  });

  const copyId = async () => {
    try {
      await navigator.clipboard.writeText(order.id);
      toast.success("Order ID copied");
    } catch {
      toast.error("Copy failed");
    }
  };

  return (
    <div className="min-h-screen bg-[image:var(--gradient-soft)]">
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 py-10">
        <Link to="/orders" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> All orders
        </Link>

        <div className="glass mt-4 rounded-3xl p-6 shadow-soft md:p-8">
          <div className="flex flex-col items-center text-center">
            <div className="grid h-14 w-14 place-items-center rounded-2xl bg-[image:var(--gradient-hero)] text-white shadow-glow">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h1 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">Order placed!</h1>
            <p className="mt-2 max-w-md text-muted-foreground">
              Message us now on WhatsApp, Telegram or Instagram to confirm payment and receive your service instantly.
            </p>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <a
              href={links.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-emerald-500 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:opacity-95"
            >
              <MessageCircle className="h-4 w-4" /> Continue on WhatsApp
            </a>
            <a
              href={links.telegram}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-sky-500 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:opacity-95"
            >
              <Send className="h-4 w-4" /> Telegram
            </a>
            <a
              href={links.instagram}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-pink-500 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:opacity-95"
            >
              <Instagram className="h-4 w-4" /> Instagram
            </a>
          </div>

          <div className="mt-8 rounded-2xl border border-border/60 bg-background/60 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs uppercase tracking-wide text-muted-foreground">Order ID</div>
              <Button size="sm" variant="ghost" onClick={copyId} className="h-7 gap-1 text-xs">
                <Copy className="h-3.5 w-3.5" /> Copy
              </Button>
            </div>
            <div className="mt-1 font-mono text-sm">#{order.id}</div>

            <div className="mt-4 flex items-start gap-3">
              <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted">
                {product?.image_url && <img src={product.image_url} alt="" className="h-full w-full object-cover" />}
              </div>
              <div className="flex-1">
                {product?.slug ? (
                  <Link to="/product/$slug" params={{ slug: product.slug }} className="font-semibold hover:underline">
                    {product.name}
                  </Link>
                ) : (
                  <div className="font-semibold">{product?.name ?? "Service"}</div>
                )}
                <div className="text-xs text-muted-foreground">
                  Qty {order.quantity ?? 1}
                  {order.coupon_code && (
                    <> · coupon <span className="font-mono">{order.coupon_code}</span></>
                  )}
                </div>
              </div>
              <div className="text-xl font-bold gradient-text">${Number(order.amount).toFixed(2)}</div>
            </div>
          </div>

          {!cancelled ? (
            <div className="mt-6">
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Status</div>
              <div className="mt-3 flex items-center justify-between gap-2">
                {STAGES.map((s, i) => {
                  const done = i <= currentStage;
                  return (
                    <div key={s.key} className="flex flex-1 flex-col items-center">
                      <div
                        className={`grid h-9 w-9 place-items-center rounded-full border-2 ${
                          done
                            ? "border-primary bg-[image:var(--gradient-hero)] text-white shadow-glow"
                            : "border-border/60 bg-muted text-muted-foreground"
                        }`}
                      >
                        <s.Icon className="h-4 w-4" />
                      </div>
                      <div className={`mt-1 text-xs ${done ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
                        {s.label}
                      </div>
                      {i < STAGES.length - 1 && (
                        <div className={`-mt-6 h-0.5 w-full ${i < currentStage ? "bg-primary" : "bg-border"}`} />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="mt-6 flex items-center justify-center">
              <Badge variant="outline" className="border-rose-200 bg-rose-100 text-rose-800">
                Cancelled
              </Badge>
            </div>
          )}

          <div className="mt-8 flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
            <Package className="h-4 w-4 text-primary" />
            Placed on {new Date(order.created_at).toLocaleString()}
          </div>
        </div>

        {!cancelled && user && (
          <PaymentSubmit orderId={order.id} userId={user.id} amount={Number(order.amount)} />
        )}

        <div className="mt-6 flex justify-center gap-2">
          <Button variant="outline" onClick={() => router.navigate({ to: "/orders" })} className="rounded-full">
            View all orders
          </Button>
          <Button asChild className="rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
            <Link to="/services">Continue shopping</Link>
          </Button>
        </div>
      </main>
      <Footer />
    </div>
  );
}
