import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Package2, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({
    meta: [
      { title: "My Orders — Subscription Fighters" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OrdersPage,
});

const statusColor: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800 border-amber-200",
  paid: "bg-emerald-100 text-emerald-800 border-emerald-200",
  delivered: "bg-sky-100 text-sky-800 border-sky-200",
  cancelled: "bg-rose-100 text-rose-800 border-rose-200",
};

function OrdersPage() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["my-orders", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("orders")
        .select("id,amount,status,coupon_code,created_at,product_id,notes")
        .order("created_at", { ascending: false });
      const ids = Array.from(new Set((data ?? []).map((o) => o.product_id)));
      const { data: prods } = ids.length
        ? await supabase.from("products").select("id,name,slug,image_url").in("id", ids)
        : { data: [] as any[] };
      const map = new Map((prods ?? []).map((p: any) => [p.id, p]));
      return (data ?? []).map((o: any) => ({ ...o, product: map.get(o.product_id) }));
    },
  });

  return (
    <div className="min-h-screen bg-[image:var(--gradient-soft)]">
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-10">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to home
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight">My orders</h1>
        <p className="mt-1 text-muted-foreground">Track the status of every service you've ordered.</p>

        <div className="mt-8 space-y-4">
          {isLoading && Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-2xl bg-muted" />
          ))}

          {data && data.length === 0 && (
            <div className="glass rounded-3xl p-10 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[image:var(--gradient-hero)] text-white shadow-glow">
                <Package2 className="h-6 w-6" />
              </div>
              <h2 className="mt-4 text-xl font-semibold">No orders yet</h2>
              <p className="mt-1 text-sm text-muted-foreground">Browse our catalog and place your first order.</p>
              <Button asChild className="mt-4 rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
                <Link to="/services">Explore services</Link>
              </Button>
            </div>
          )}

          {(data ?? []).map((o: any) => (
            <div key={o.id} className="glass flex flex-col gap-3 rounded-2xl p-4 sm:flex-row sm:items-center">
              <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted">
                {o.product?.image_url && <img src={o.product.image_url} alt="" className="h-full w-full object-cover" />}
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  {o.product?.slug ? (
                    <Link to="/product/$slug" params={{ slug: o.product.slug }} className="font-semibold hover:underline">
                      {o.product?.name ?? "Service"}
                    </Link>
                  ) : (
                    <span className="font-semibold">{o.product?.name ?? "Service"}</span>
                  )}
                  <Badge variant="outline" className={statusColor[o.status] ?? ""}>{o.status}</Badge>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  #{o.id.slice(0, 8)} · {new Date(o.created_at).toLocaleString()}
                  {o.coupon_code && <> · coupon <span className="font-mono">{o.coupon_code}</span></>}
                </div>
              </div>
              <div className="text-lg font-bold gradient-text sm:text-xl">${Number(o.amount).toFixed(2)}</div>
            </div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
