import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Heart, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/wishlist")({
  head: () => ({
    meta: [
      { title: "My Wishlist — Subscription Fighters" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: WishlistPage,
});

function WishlistPage() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["wishlist", "list", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: rows } = await supabase
        .from("wishlist")
        .select("product_id, created_at")
        .order("created_at", { ascending: false });
      const ids = (rows ?? []).map((r) => r.product_id);
      if (!ids.length) return [] as ProductCardData[];
      const { data: prods } = await supabase
        .from("products")
        .select("id,name,slug,short_description,price,image_url,featured")
        .in("id", ids)
        .eq("active", true);
      return (prods ?? []) as ProductCardData[];
    },
  });

  return (
    <div className="min-h-screen bg-[image:var(--gradient-soft)]">
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to home
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">My wishlist</h1>
        <p className="mt-1 text-muted-foreground">Your saved services, ready to check out anytime.</p>

        <div className="mt-8">
          {isLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-72 animate-pulse rounded-2xl bg-muted" />)}
            </div>
          ) : (data ?? []).length === 0 ? (
            <div className="glass rounded-3xl p-10 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[image:var(--gradient-hero)] text-white shadow-glow">
                <Heart className="h-6 w-6" />
              </div>
              <h2 className="mt-4 text-xl font-semibold">Nothing saved yet</h2>
              <p className="mt-1 text-sm text-muted-foreground">Tap the heart on any service to save it here.</p>
              <Button asChild className="mt-4 rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
                <Link to="/services">Browse services</Link>
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {(data ?? []).map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
