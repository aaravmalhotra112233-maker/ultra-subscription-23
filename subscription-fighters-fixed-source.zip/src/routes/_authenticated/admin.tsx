import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import {
  Package, Plus, Trash2, Pencil, Tag, Users, DollarSign, Loader2, Sparkles, LogOut, ArrowLeft, Search, TicketPercent, ShoppingBag, Upload,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PaymentsAdmin } from "@/components/admin/PaymentsAdmin";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin — Subscription Fighters" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

function Admin() {
  const { user, isAdmin, loading, adminLoading } = useAuth();
  const router = useRouter();

  if (loading || adminLoading) return <div className="grid min-h-screen place-items-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  if (!isAdmin) {
    return (
      <div>
        <Navbar />
        <div className="mx-auto max-w-md px-4 py-24 text-center">
          <h1 className="text-2xl font-bold">Not authorized</h1>
          <p className="mt-2 text-muted-foreground">This dashboard is for admins only.</p>
          <Button asChild className="mt-6"><Link to="/">Go home</Link></Button>
        </div>
      </div>
    );
  }

  const signOut = async () => { await supabase.auth.signOut(); router.navigate({ to: "/" }); };

  return (
    <div className="min-h-screen bg-[image:var(--gradient-soft)]">
      <header className="glass sticky top-0 z-30 border-b border-border/50">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/" className="grid h-9 w-9 place-items-center rounded-xl bg-[image:var(--gradient-hero)] text-white shadow-glow"><Sparkles className="h-5 w-5" /></Link>
            <div>
              <div className="text-sm text-muted-foreground">Subscription Fighters</div>
              <div className="font-semibold">Admin Dashboard</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link to="/"><ArrowLeft className="mr-1 h-4 w-4" /> Site</Link></Button>
            <Button variant="outline" size="sm" onClick={signOut}><LogOut className="mr-1 h-4 w-4" /> Sign out</Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8">
        <Stats />
        <Tabs defaultValue="products" className="mt-8">
          <TabsList className="rounded-full flex-wrap h-auto">
            <TabsTrigger value="products" className="rounded-full"><Package className="mr-1 h-4 w-4" /> Products</TabsTrigger>
            <TabsTrigger value="categories" className="rounded-full"><Tag className="mr-1 h-4 w-4" /> Categories</TabsTrigger>
            <TabsTrigger value="coupons" className="rounded-full"><TicketPercent className="mr-1 h-4 w-4" /> Coupons</TabsTrigger>
            <TabsTrigger value="orders" className="rounded-full"><ShoppingBag className="mr-1 h-4 w-4" /> Orders</TabsTrigger>
            <TabsTrigger value="payments" className="rounded-full"><TicketPercent className="mr-1 h-4 w-4" /> Payments</TabsTrigger>
            <TabsTrigger value="users" className="rounded-full"><Users className="mr-1 h-4 w-4" /> Users</TabsTrigger>
          </TabsList>
          <TabsContent value="payments" className="mt-4"><PaymentsAdmin /></TabsContent>
          <TabsContent value="products" className="mt-4"><ProductsAdmin /></TabsContent>
          <TabsContent value="categories" className="mt-4"><CategoriesAdmin /></TabsContent>
          <TabsContent value="coupons" className="mt-4"><CouponsAdmin /></TabsContent>
          <TabsContent value="orders" className="mt-4"><OrdersAdmin /></TabsContent>
          <TabsContent value="users" className="mt-4"><UsersAdmin /></TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function Stats() {
  const { data } = useQuery({
    queryKey: ["admin", "stats"],
    queryFn: async () => {
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      const [p, u, oPending, oMonth] = await Promise.all([
        supabase.from("products").select("id,active,featured,price"),
        supabase.from("profiles").select("id"),
        supabase.from("orders").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase
          .from("orders")
          .select("amount,status,created_at")
          .in("status", ["paid", "delivered"])
          .gte("created_at", monthStart.toISOString()),
      ]);
      const revenue = (oMonth.data ?? []).reduce((s: number, o: any) => s + Number(o.amount ?? 0), 0);
      return {
        products: p.data ?? [],
        users: u.data ?? [],
        pending: oPending.count ?? 0,
        revenue,
      };
    },
  });
  const active = data?.products.filter((x: any) => x.active).length ?? 0;

  const items = [
    { Icon: DollarSign, label: "Revenue (this month)", value: data ? `$${data.revenue.toFixed(2)}` : "—" },
    { Icon: ShoppingBag, label: "Pending orders", value: data?.pending ?? "—" },
    { Icon: Package, label: "Active products", value: `${active} / ${data?.products.length ?? "—"}` },
    { Icon: Users, label: "Users", value: data?.users.length ?? "—" },
  ];
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {items.map(({ Icon, label, value }) => (
        <div key={label} className="glass rounded-2xl p-5 shadow-soft">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">{label}</div>
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-[image:var(--gradient-hero)] text-white"><Icon className="h-4 w-4" /></div>
          </div>
          <div className="mt-3 text-3xl font-bold gradient-text">{value}</div>
        </div>
      ))}
    </div>
  );
}

const productSchema = z.object({
  name: z.string().trim().min(1, "Name required").max(120),
  slug: z.string().trim().min(1, "Slug required").max(120).regex(/^[a-z0-9-]+$/, "Lowercase, hyphens only"),
  short_description: z.string().max(300).optional().nullable(),
  description: z.string().max(5000).optional().nullable(),
  features: z.string().max(2000).optional().nullable(),
  price: z.number().min(0).max(999999),
  image_url: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  category_id: z.string().uuid().nullable().optional(),
  featured: z.boolean(),
  active: z.boolean(),
});
type ProductForm = z.infer<typeof productSchema>;

const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");

function ProductsAdmin() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState<any | null>(null);
  const [open, setOpen] = useState(false);

  const { data: products } = useQuery({
    queryKey: ["admin", "products"],
    queryFn: async () => (await supabase.from("products").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => (await supabase.from("categories").select("id,name").order("name")).data ?? [],
  });

  const filtered = useMemo(() => (products ?? []).filter((p: any) => p.name.toLowerCase().includes(q.toLowerCase())), [products, q]);

  const del = async (id: string) => {
    if (!confirm("Delete this product?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["admin", "products"] });
  };

  return (
    <div>
      <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative sm:w-72">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search products..." className="pl-9" />
        </div>
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setEditing(null); }}>
          <DialogTrigger asChild>
            <Button className="rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95"><Plus className="mr-1 h-4 w-4" /> New product</Button>
          </DialogTrigger>
          <ProductDialog
            editing={editing}
            categories={categories ?? []}
            onSaved={() => { setOpen(false); setEditing(null); qc.invalidateQueries({ queryKey: ["admin", "products"] }); qc.invalidateQueries({ queryKey: ["products"] }); }}
          />
        </Dialog>
      </div>

      <div className="glass mt-4 overflow-hidden rounded-2xl">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-8">No products yet.</TableCell></TableRow>
            )}
            {filtered.map((p: any) => (
              <TableRow key={p.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-muted">
                      {p.image_url && <img src={p.image_url} alt="" className="h-full w-full object-cover" />}
                    </div>
                    <div>
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs text-muted-foreground">/{p.slug}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>${Number(p.price).toFixed(2)}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    {p.active ? <Badge variant="secondary">Active</Badge> : <Badge variant="outline">Hidden</Badge>}
                    {p.featured && <Badge className="bg-[image:var(--gradient-hero)] text-white">Featured</Badge>}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(p); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(p.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function ProductDialog({ editing, categories, onSaved }: { editing: any; categories: any[]; onSaved: () => void }) {
  const [form, setForm] = useState<ProductForm>(() => ({
    name: editing?.name ?? "",
    slug: editing?.slug ?? "",
    short_description: editing?.short_description ?? "",
    description: editing?.description ?? "",
    features: (editing?.features ?? []).join("\n"),
    price: editing?.price ? Number(editing.price) : 0,
    image_url: editing?.image_url ?? "",
    category_id: editing?.category_id ?? null,
    featured: editing?.featured ?? false,
    active: editing?.active ?? true,
  }));
  const [saving, setSaving] = useState(false);

  const save = async () => {
    const parsed = productSchema.safeParse(form);
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setSaving(true);
    const features = (parsed.data.features ?? "").split("\n").map(s => s.trim()).filter(Boolean);
    const payload = {
      name: parsed.data.name,
      slug: parsed.data.slug,
      short_description: parsed.data.short_description || null,
      description: parsed.data.description || null,
      features,
      price: parsed.data.price,
      image_url: parsed.data.image_url || null,
      category_id: parsed.data.category_id || null,
      featured: parsed.data.featured,
      active: parsed.data.active,
    };
    const q = editing
      ? supabase.from("products").update(payload).eq("id", editing.id)
      : supabase.from("products").insert(payload);
    const { error } = await q;
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(editing ? "Updated" : "Product created");
    onSaved();
  };

  return (
    <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
      <DialogHeader><DialogTitle>{editing ? "Edit product" : "New product"}</DialogTitle></DialogHeader>
      <div className="grid gap-4 py-2 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Label>Name</Label>
          <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value, slug: f.slug || slugify(e.target.value) }))} />
        </div>
        <div className="sm:col-span-2">
          <Label>Slug</Label>
          <Input value={form.slug} onChange={e => setForm(f => ({ ...f, slug: slugify(e.target.value) }))} />
        </div>
        <div className="sm:col-span-2">
          <Label>Short description</Label>
          <Input value={form.short_description ?? ""} onChange={e => setForm(f => ({ ...f, short_description: e.target.value }))} />
        </div>
        <div className="sm:col-span-2">
          <Label>Full description</Label>
          <Textarea rows={4} value={form.description ?? ""} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
        </div>
        <div className="sm:col-span-2">
          <Label>Features (one per line)</Label>
          <Textarea rows={4} value={form.features ?? ""} onChange={e => setForm(f => ({ ...f, features: e.target.value }))} placeholder="1 month subscription&#10;Instant delivery&#10;24/7 support" />
        </div>
        <div>
          <Label>Price (USD)</Label>
          <Input type="number" step="0.01" value={form.price} onChange={e => setForm(f => ({ ...f, price: Number(e.target.value) }))} />
        </div>
        <div>
          <Label>Category</Label>
          <Select value={form.category_id ?? "none"} onValueChange={v => setForm(f => ({ ...f, category_id: v === "none" ? null : v }))}>
            <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="sm:col-span-2">
          <Label>Product image</Label>
          <div className="mt-2 flex items-start gap-3">
            <div className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-muted">
              {form.image_url ? <img src={form.image_url} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-xs text-muted-foreground">No image</div>}
            </div>
            <div className="flex-1 space-y-2">
              <Input value={form.image_url ?? ""} onChange={e => setForm(f => ({ ...f, image_url: e.target.value }))} placeholder="https://... or upload below" />
              <ImageUpload onUploaded={(url) => setForm(f => ({ ...f, image_url: url }))} />
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Switch checked={form.featured} onCheckedChange={v => setForm(f => ({ ...f, featured: v }))} />
          <Label>Featured</Label>
        </div>
        <div className="flex items-center gap-3">
          <Switch checked={form.active} onCheckedChange={v => setForm(f => ({ ...f, active: v }))} />
          <Label>Active</Label>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={save} disabled={saving} className="bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

function CategoriesAdmin() {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const { data } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => (await supabase.from("categories").select("*").order("name")).data ?? [],
  });

  const add = async () => {
    const n = name.trim();
    if (!n) return;
    const slug = slugify(n);
    const { error } = await supabase.from("categories").insert({ name: n, slug });
    if (error) return toast.error(error.message);
    setName("");
    qc.invalidateQueries({ queryKey: ["categories"] });
    toast.success("Category added");
  };
  const del = async (id: string) => {
    if (!confirm("Delete category?")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["categories"] });
  };

  return (
    <div>
      <div className="glass flex gap-2 rounded-2xl p-3">
        <Input value={name} onChange={e => setName(e.target.value)} placeholder="New category name" />
        <Button onClick={add} className="bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95"><Plus className="mr-1 h-4 w-4" /> Add</Button>
      </div>
      <div className="glass mt-4 overflow-hidden rounded-2xl">
        <Table>
          <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Slug</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
          <TableBody>
            {(data ?? []).map((c: any) => (
              <TableRow key={c.id}>
                <TableCell className="font-medium">{c.name}</TableCell>
                <TableCell className="text-muted-foreground">/{c.slug}</TableCell>
                <TableCell className="text-right">
                  <Button size="icon" variant="ghost" onClick={() => del(c.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function UsersAdmin() {
  const { data } = useQuery({
    queryKey: ["admin", "users"],
    queryFn: async () => {
      const [p, r] = await Promise.all([
        supabase.from("profiles").select("id,email,full_name,created_at").order("created_at", { ascending: false }),
        supabase.from("user_roles").select("user_id,role"),
      ]);
      const roles = new Map<string, string[]>();
      (r.data ?? []).forEach((x: any) => {
        roles.set(x.user_id, [...(roles.get(x.user_id) ?? []), x.role]);
      });
      return (p.data ?? []).map((u: any) => ({ ...u, roles: roles.get(u.id) ?? [] }));
    },
  });

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <Table>
        <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Email</TableHead><TableHead>Roles</TableHead><TableHead>Joined</TableHead></TableRow></TableHeader>
        <TableBody>
          {(data ?? []).length === 0 && <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-8">No users yet.</TableCell></TableRow>}
          {(data ?? []).map((u: any) => (
            <TableRow key={u.id}>
              <TableCell className="font-medium">{u.full_name ?? "—"}</TableCell>
              <TableCell>{u.email}</TableCell>
              <TableCell>{u.roles.map((r: string) => <Badge key={r} variant="secondary" className="mr-1">{r}</Badge>)}</TableCell>
              <TableCell className="text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function ImageUpload({ onUploaded }: { onUploaded: (url: string) => void }) {
  const [busy, setBusy] = useState(false);
  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast.error("Max 5MB"); return; }
    setBusy(true);
    const ext = file.name.split(".").pop() ?? "png";
    const path = `products/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("products").upload(path, file, { upsert: false, contentType: file.type });
    if (error) { setBusy(false); toast.error(error.message); return; }
    const { data, error: sErr } = await supabase.storage.from("products").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
    setBusy(false);
    if (sErr || !data) { toast.error(sErr?.message ?? "Failed to sign URL"); return; }
    onUploaded(data.signedUrl);
    toast.success("Image uploaded");
    e.target.value = "";
  };
  return (
    <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-primary/40 bg-primary/5 px-3 py-2 text-sm hover:bg-primary/10">
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
      <span>{busy ? "Uploading..." : "Upload image"}</span>
      <input type="file" accept="image/*" className="hidden" onChange={onFile} disabled={busy} />
    </label>
  );
}

const couponSchema = z.object({
  code: z.string().trim().min(2).max(40).regex(/^[A-Z0-9_-]+$/, "Uppercase letters, digits, - and _ only"),
  discount_percent: z.number().int().min(1).max(100),
  active: z.boolean(),
  max_uses: z.number().int().min(0).nullable().optional(),
  expires_at: z.string().nullable().optional(),
});

function CouponsAdmin() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ code: "", discount_percent: 10, active: true, max_uses: "", expires_at: "" });
  const [saving, setSaving] = useState(false);
  const { data } = useQuery({
    queryKey: ["admin", "coupons"],
    queryFn: async () => (await supabase.from("coupons").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const save = async () => {
    const parsed = couponSchema.safeParse({
      code: form.code.trim().toUpperCase(),
      discount_percent: Number(form.discount_percent),
      active: form.active,
      max_uses: form.max_uses ? Number(form.max_uses) : null,
      expires_at: form.expires_at || null,
    });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setSaving(true);
    const { error } = await supabase.from("coupons").insert(parsed.data);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Coupon created");
    setForm({ code: "", discount_percent: 10, active: true, max_uses: "", expires_at: "" });
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["admin", "coupons"] });
  };

  const toggle = async (id: string, active: boolean) => {
    const { error } = await supabase.from("coupons").update({ active }).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "coupons"] });
  };
  const del = async (id: string) => {
    if (!confirm("Delete coupon?")) return;
    const { error } = await supabase.from("coupons").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "coupons"] });
  };

  return (
    <div>
      <div className="flex justify-end">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-full bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95"><Plus className="mr-1 h-4 w-4" /> New coupon</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New coupon</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2">
              <div><Label>Code</Label><Input className="uppercase" value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))} placeholder="WELCOME10" /></div>
              <div><Label>Discount %</Label><Input type="number" min={1} max={100} value={form.discount_percent} onChange={e => setForm(f => ({ ...f, discount_percent: Number(e.target.value) }))} /></div>
              <div><Label>Max uses (optional)</Label><Input type="number" min={0} value={form.max_uses} onChange={e => setForm(f => ({ ...f, max_uses: e.target.value }))} /></div>
              <div><Label>Expires at (optional)</Label><Input type="datetime-local" value={form.expires_at} onChange={e => setForm(f => ({ ...f, expires_at: e.target.value }))} /></div>
              <div className="flex items-center gap-3"><Switch checked={form.active} onCheckedChange={v => setForm(f => ({ ...f, active: v }))} /><Label>Active</Label></div>
            </div>
            <DialogFooter><Button onClick={save} disabled={saving} className="bg-[image:var(--gradient-hero)] shadow-glow hover:opacity-95">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create"}</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <div className="glass mt-4 overflow-hidden rounded-2xl">
        <Table>
          <TableHeader><TableRow><TableHead>Code</TableHead><TableHead>Discount</TableHead><TableHead>Usage</TableHead><TableHead>Expires</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
          <TableBody>
            {(data ?? []).length === 0 && <TableRow><TableCell colSpan={6} className="py-8 text-center text-muted-foreground">No coupons yet.</TableCell></TableRow>}
            {(data ?? []).map((c: any) => (
              <TableRow key={c.id}>
                <TableCell className="font-mono font-semibold">{c.code}</TableCell>
                <TableCell>{c.discount_percent}%</TableCell>
                <TableCell>{c.used_count}{c.max_uses ? ` / ${c.max_uses}` : ""}</TableCell>
                <TableCell className="text-muted-foreground">{c.expires_at ? new Date(c.expires_at).toLocaleDateString() : "—"}</TableCell>
                <TableCell><Switch checked={c.active} onCheckedChange={(v) => toggle(c.id, v)} /></TableCell>
                <TableCell className="text-right"><Button size="icon" variant="ghost" onClick={() => del(c.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

const ORDER_STATUSES = ["pending", "paid", "delivered", "cancelled"] as const;

function OrdersAdmin() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin", "orders"],
    queryFn: async () => {
      const { data: orders } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
      const pIds = Array.from(new Set((orders ?? []).map((o: any) => o.product_id)));
      const uIds = Array.from(new Set((orders ?? []).map((o: any) => o.user_id)));
      const [{ data: prods }, { data: profs }] = await Promise.all([
        pIds.length ? supabase.from("products").select("id,name,slug").in("id", pIds) : Promise.resolve({ data: [] as any[] }),
        uIds.length ? supabase.from("profiles").select("id,email,full_name").in("id", uIds) : Promise.resolve({ data: [] as any[] }),
      ]);
      const pMap = new Map((prods ?? []).map((p: any) => [p.id, p]));
      const uMap = new Map((profs ?? []).map((p: any) => [p.id, p]));
      return (orders ?? []).map((o: any) => ({ ...o, product: pMap.get(o.product_id), profile: uMap.get(o.user_id) }));
    },
  });

  const setStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${status}`);
    qc.invalidateQueries({ queryKey: ["admin", "orders"] });
  };
  const del = async (id: string) => {
    if (!confirm("Delete order?")) return;
    const { error } = await supabase.from("orders").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin", "orders"] });
  };

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <Table>
        <TableHeader><TableRow><TableHead>Order</TableHead><TableHead>Customer</TableHead><TableHead>Product</TableHead><TableHead>Amount</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
        <TableBody>
          {(data ?? []).length === 0 && <TableRow><TableCell colSpan={6} className="py-8 text-center text-muted-foreground">No orders yet.</TableCell></TableRow>}
          {(data ?? []).map((o: any) => (
            <TableRow key={o.id}>
              <TableCell>
                <div className="font-mono text-xs">#{o.id.slice(0, 8)}</div>
                <div className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()}</div>
                {o.coupon_code && <div className="text-xs text-primary">🎟 {o.coupon_code}</div>}
              </TableCell>
              <TableCell>
                <div className="text-sm">{o.profile?.full_name ?? "—"}</div>
                <div className="text-xs text-muted-foreground">{o.profile?.email}</div>
              </TableCell>
              <TableCell>{o.product?.name ?? "—"}</TableCell>
              <TableCell className="font-semibold">${Number(o.amount).toFixed(2)}</TableCell>
              <TableCell>
                <Select value={o.status} onValueChange={(v) => setStatus(o.id, v)}>
                  <SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger>
                  <SelectContent>{ORDER_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </TableCell>
              <TableCell className="text-right"><Button size="icon" variant="ghost" onClick={() => del(o.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
