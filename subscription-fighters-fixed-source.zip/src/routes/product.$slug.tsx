import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check, MessageCircle, Instagram, Send, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FloatingContact } from "@/components/FloatingContact";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Reviews } from "@/components/Reviews";
import { BuyPanel } from "@/components/BuyPanel";
import { contactLinks } from "@/lib/contact";
import { BuyIntentProvider, useBuyIntent } from "@/lib/buyIntent";
import { Price } from "@/lib/currency";
import { ImageZoom } from "@/components/ImageZoom";


export const Route = createFileRoute("/product/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug} — Subscription Fighters` },
      { property: "og:url", content: `/product/${params.slug}` },
      { property: "og:type", content: "product" },
    ],
    links: [{ rel: "canonical", href: `/product/${params.slug}` }],
  }),
  component: ProductPage,
  notFoundComponent: () => (
    <div>
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="text-4xl font-bold">Service not found</h1>
        <p className="mt-3 text-muted-foreground">The service you're looking for doesn't exist or was removed.</p>
        <Button asChild className="mt-6"><Link to="/services">Browse all services</Link></Button>
      </main>
      <Footer />
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-3xl px-4 py-24 text-center">
      <h1 className="text-2xl font-bold">Something went wrong</h1>
      <p className="mt-3 text-muted-foreground">{error.message}</p>
    </div>
  ),
});

function ProductPage() {
  const { slug } = Route.useParams();
  const { data: product, isLoading } = useQuery({
    queryKey: ["product", slug],
    queryFn: async () => {
      const { data } = await supabase.from("products")
        .select("*")
        .eq("slug", slug).eq("active", true).maybeSingle();
      if (!data) throw notFound();
      return data;
    },
  });

  const { data: related } = useQuery({
    queryKey: ["product", slug, "related", product?.category_id],
    enabled: !!product,
    queryFn: async () => {
      const { data } = await supabase.from("products")
        .select("id,name,slug,short_description,price,image_url,featured")
        .eq("active", true)
        .neq("id", product!.id)
        .eq("category_id", product!.category_id ?? "")
        .limit(3);
      return (data ?? []) as ProductCardData[];
    },
  });

  if (isLoading || !product) {
    return (
      <div>
        <Navbar />
        <main className="mx-auto max-w-6xl px-4 py-16">
          <div className="grid gap-8 md:grid-cols-2">
            <div className="h-96 animate-pulse rounded-3xl bg-muted" />
            <div className="space-y-4">
              <div className="h-8 w-2/3 animate-pulse rounded bg-muted" />
              <div className="h-4 w-full animate-pulse rounded bg-muted" />
              <div className="h-4 w-5/6 animate-pulse rounded bg-muted" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  const features = (product.features ?? []) as string[];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.short_description || product.description || undefined,
    image: product.image_url || undefined,
    brand: { "@type": "Brand", name: "Subscription Fighters" },
    offers: {
      "@type": "Offer",
      price: Number(product.price),
      priceCurrency: "USD",
      availability: "https://schema.org/InStock",
      url: `/product/${product.slug}`,
    },
  };

  return (
    <BuyIntentProvider productName={product.name} price={Number(product.price)}>
    <div>
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-8 md:py-12">
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Link to="/services" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to services
        </Link>


        <div className="mt-6 grid gap-10 md:grid-cols-2">
          <div className="glass overflow-hidden rounded-3xl p-2 shadow-soft">
            <div className="aspect-square overflow-hidden rounded-2xl bg-[image:var(--gradient-soft)]">
              {product.image_url ? (
                <ImageZoom src={product.image_url} alt={product.name} />
              ) : <div className="grid h-full place-items-center text-primary/40">No image</div>}
            </div>
            {product.image_url && (
              <p className="pb-1 pt-2 text-center text-xs text-muted-foreground">Tap the image to view it full size</p>
            )}
          </div>

          <div>
            <h1 className="text-3xl font-bold tracking-tight md:text-4xl">{product.name}</h1>
            {product.short_description && <p className="mt-3 text-muted-foreground">{product.short_description}</p>}
            <div className="mt-6 flex items-baseline gap-3">
              <span className="text-4xl font-bold gradient-text"><Price usd={Number(product.price)} /></span>
              <span className="text-sm text-muted-foreground">one-time / as listed</span>
            </div>


            {features.length > 0 && (
              <ul className="mt-6 space-y-2">
                {features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="mt-0.5 h-4 w-4 text-primary" /> <span>{f}</span>
                  </li>
                ))}
              </ul>
            )}

            <BuyPanel productId={product.id} productName={product.name} price={Number(product.price)} />

            <BuyChatButtons productName={product.name} />
            <p className="mt-3 text-xs text-muted-foreground">Prefer chat? Message us on any channel — your quantity, coupon and total are included automatically.</p>
          </div>
        </div>

        <Reviews productId={product.id} />

        {product.description && (
          <section className="mt-14">
            <h2 className="text-2xl font-bold tracking-tight">About this service</h2>
            <div className="prose prose-slate mt-4 max-w-none whitespace-pre-wrap text-foreground/80">{product.description}</div>
          </section>
        )}

        <section className="mt-14">
          <h2 className="text-2xl font-bold tracking-tight">FAQ</h2>
          <Accordion type="single" collapsible className="mt-4">
            {[
              { q: "How fast is delivery?", a: "Usually within a few minutes after payment confirmation via chat." },
              { q: "What payment methods do you accept?", a: "We accept multiple methods — chat with us and we'll share available options for your region." },
              { q: "Is there a warranty?", a: "Yes. Every subscription comes with a working guarantee for its listed duration." },
            ].map((f, i) => (
              <AccordionItem key={i} value={`f-${i}`} className="glass mb-3 rounded-2xl px-4">
                <AccordionTrigger className="text-left font-semibold">{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>

        {related && related.length > 0 && (
          <section className="mt-14">
            <h2 className="text-2xl font-bold tracking-tight">Related services</h2>
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map(p => <ProductCard key={p.id} p={p} />)}
            </div>
          </section>
        )}
      </main>
      <Footer />
      <FloatingContact productName={product.name} />
    </div>
    </BuyIntentProvider>
  );
}

function BuyChatButtons({ productName }: { productName: string }) {
  const buy = useBuyIntent();
  const c = buy
    ? contactLinks(buy.intent.productName ?? productName, {
        quantity: buy.intent.quantity,
        unitPrice: buy.intent.unitPrice,
        total: buy.intent.total,
        couponCode: buy.intent.couponCode,
        couponPercent: buy.intent.couponPercent,
        couponExpiresAt: buy.intent.couponExpiresAt,
      })
    : contactLinks(productName);
  return (
    <div className="mt-6 grid gap-3 sm:grid-cols-3">
      <Button asChild size="lg" className="w-full rounded-full bg-emerald-500 shadow-glow hover:bg-emerald-500/90">
        <a href={c.whatsapp} target="_blank" rel="noreferrer"><MessageCircle className="mr-1 h-4 w-4" /> WhatsApp</a>
      </Button>
      <Button asChild size="lg" className="w-full rounded-full bg-pink-500 shadow-glow hover:bg-pink-500/90">
        <a href={c.instagram} target="_blank" rel="noreferrer"><Instagram className="mr-1 h-4 w-4" /> Instagram</a>
      </Button>
      <Button asChild size="lg" className="w-full rounded-full bg-sky-500 shadow-glow hover:bg-sky-500/90">
        <a href={c.telegram} target="_blank" rel="noreferrer"><Send className="mr-1 h-4 w-4" /> Telegram</a>
      </Button>
    </div>
  );
}
