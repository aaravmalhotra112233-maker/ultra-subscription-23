import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FloatingContact } from "@/components/FloatingContact";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "All Services — Subscription Fighters" },
      { name: "description", content: "Browse every premium AI tool, editing suite and digital membership we sell. Search, filter and find your perfect stack." },
      { property: "og:title", content: "All Services — Subscription Fighters" },
      { property: "og:description", content: "Every premium AI tool, editing suite and membership on Subscription Fighters." },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: Services,
});

type Product = ProductCardData & { category_id: string | null; created_at: string };

function Services() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [sort, setSort] = useState<string>("newest");

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => (await supabase.from("categories").select("id,name,slug").order("name")).data ?? [],
  });
  const { data: products, isLoading } = useQuery({
    queryKey: ["products", "all"],
    queryFn: async () => (await supabase.from("products")
      .select("id,name,slug,short_description,price,image_url,featured,category_id,created_at")
      .eq("active", true)).data as Product[] ?? [],
  });

  const filtered = useMemo(() => {
    let items = products ?? [];
    if (cat !== "all") items = items.filter(p => p.category_id === cat);
    if (q.trim()) {
      const s = q.toLowerCase();
      items = items.filter(p => p.name.toLowerCase().includes(s) || (p.short_description ?? "").toLowerCase().includes(s));
    }
    const sorted = [...items];
    if (sort === "price-asc") sorted.sort((a, b) => Number(a.price) - Number(b.price));
    else if (sort === "price-desc") sorted.sort((a, b) => Number(b.price) - Number(a.price));
    else if (sort === "name") sorted.sort((a, b) => a.name.localeCompare(b.name));
    else sorted.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    return sorted;
  }, [products, q, cat, sort]);

  return (
    <div>
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-10">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <Badge variant="secondary" className="mb-2">Catalog</Badge>
            <h1 className="text-4xl font-bold tracking-tight md:text-5xl">All services</h1>
            <p className="mt-2 text-muted-foreground">Search, filter and find the perfect digital service.</p>
          </div>
        </div>

        <div className="glass mt-6 flex flex-col gap-3 rounded-2xl p-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search services..." className="border-0 bg-white/60 pl-9" />
          </div>
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="w-full border-0 bg-white/60 md:w-52"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {(categories ?? []).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="w-full border-0 bg-white/60 md:w-52"><SelectValue placeholder="Sort" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price-asc">Price: Low to High</SelectItem>
              <SelectItem value="price-desc">Price: High to Low</SelectItem>
              <SelectItem value="name">Name (A-Z)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="mt-8">
          {isLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-72 animate-pulse rounded-2xl bg-muted" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-12 text-center text-muted-foreground">
              No services match your filters yet.
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map(p => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </div>
      </main>
      <Footer />
      <FloatingContact />
    </div>
  );
}
