import { useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

const ADMIN_EMAIL = "zzaibi265@gmail.com";

export function useAuth() {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminCheckStatus, setAdminCheckStatus] = useState<"idle" | "checking" | "done">("idle");

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      setAdminCheckStatus("idle");
      setLoading(false);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      setAdminCheckStatus("done");
      return;
    }

    if (user.email?.toLowerCase() !== ADMIN_EMAIL) {
      setIsAdmin(false);
      setAdminCheckStatus("done");
      return;
    }

    let active = true;
    setAdminCheckStatus("checking");
    supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "admin")
      .maybeSingle()
      .then(({ data, error }) => {
        if (!active) return;
        setIsAdmin(!error && !!data);
        if (active) setAdminCheckStatus("done");
      }, () => {
        if (!active) return;
        setIsAdmin(false);
        setAdminCheckStatus("done");
      });

    return () => { active = false; };
  }, [user]);

  return { session, user, loading, isAdmin, adminLoading: !!user && adminCheckStatus !== "done" };
}
